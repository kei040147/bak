package server

import (
	"ws-selector/api/serializers"
	"ws-selector/common/configure"
	"ws-selector/common/constants"
	"ws-selector/common/response"
	respErr "ws-selector/common/response/error"
	"ws-selector/utilities/local"
	"ws-selector/utilities/service_ws_selector"

	"github.com/gofiber/fiber/v2"
)

var cfg = configure.GetConfig()

type Controller interface {
	GetInfo(ctx *fiber.Ctx) error
}

type controller struct {
	service serviceInterface
}

func New() Controller {
	return &controller{
		service: newService(),
	}
}

func (ctrl *controller) GetInfo(ctx *fiber.Ctx) error {
	var requestBody serializers.ServerGetInfoBodyValidate
	if err := ctx.BodyParser(&requestBody); err != nil {
		return response.New(ctx, response.Options{Code: fiber.StatusBadRequest, Data: respErr.ErrFieldWrongType})
	}
	if err := requestBody.Validate(); err != nil {
		return err
	}
	currentUsername := local.New(ctx).GetUsername()
	numRoutine := len(requestBody.Servers)
	infoChan := make(chan serializers.ServerGetInfoResponseItem, numRoutine)
	result := make([]serializers.ServerGetInfoResponseItem, numRoutine)
	for _, server := range requestBody.Servers {
		switch server {
		case constants.ServerWsMessage:
			go func() {
				_, info, _ := service_ws_selector.New(
					cfg.MsgWsSelectorDomain,
					service_ws_selector.Option{
						AccessToken: cfg.MsgWsSelectorAccessToken,
					},
				).GetServerInfoByUsername("api/msgws-selector/v1/servers/get-info-by-username", currentUsername)
				data := serializers.ServerGetInfoResponseItem{
					Domain:    "",
					TokenType: "",
					Server:    constants.ServerWsMessage,
				}
				if info != nil {
					data.Domain = info.Data.Domain
					data.TokenType = info.Data.TokenType
				}
				infoChan <- data
			}()
		case constants.ServerWsSgi:
			go func() {
				_, info, _ := service_ws_selector.New(
					cfg.SgiWsSelectorDomain,
					service_ws_selector.Option{
						AccessToken: cfg.SgiWsSelectorAccessToken,
					},
				).GetServerInfoByUsername("api/sgi-ws-selector/v1/servers/get-info-by-username", currentUsername)
				data := serializers.ServerGetInfoResponseItem{
					Domain:    "",
					TokenType: "",
					Server:    constants.ServerWsSgi,
				}
				if info != nil {
					data.Domain = info.Data.Domain
					data.TokenType = info.Data.TokenType
				}
				infoChan <- data
			}()
		}
	}
	for i := 0; i < numRoutine; i++ {
		result[i] = <-infoChan
	}
	close(infoChan)
	return response.New(ctx, response.Options{
		Code: fiber.StatusOK,
		Data: result,
	})
}

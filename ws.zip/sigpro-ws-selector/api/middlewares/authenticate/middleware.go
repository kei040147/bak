package authenticate

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"

	"github.com/bytedance/sonic"
	"ws-selector/common/configure"
	"ws-selector/common/constants"
	"ws-selector/common/logging"
	"ws-selector/common/response"
	"ws-selector/database/mongo/queries"
	"ws-selector/utilities/crypto/aes/aes128"
	"ws-selector/utilities/crypto/caesar"
	jwt "ws-selector/utilities/jwt/client"
	"ws-selector/utilities/local"

	"github.com/gofiber/fiber/v2"
)

const headerHash = "hash"

var cfg = configure.GetConfig()

func Authenticate(ctx *fiber.Ctx) (err error) {
	if err = tokenAuthenticate(ctx); err != nil {
		return err
	}
	if err = verifyHashHeaderV2(ctx); err != nil {
		return err
	}
	return ctx.Next()
}

func tokenAuthenticate(ctx *fiber.Ctx) error {
	tokenString := ctx.Get(fiber.HeaderAuthorization)
	if !strings.HasPrefix(tokenString, cfg.TokenType) {
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Token missing", HttpStatusCode: fiber.StatusBadRequest})
	}
	tokenString = strings.TrimSpace(strings.TrimPrefix(tokenString, cfg.TokenType))
	jwtService := jwt.New()
	localService := local.New(ctx)
	token, parts, payload, err := jwtService.ParseUnverified(tokenString)
	if err != nil {
		byteData, _ := sonic.Marshal(fiber.Map{
			"token_string": tokenString,
			"error":        err.Error(),
		})
		localService.SetExtraBody(byteData)
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Token is wrong format", HttpStatusCode: fiber.StatusBadRequest})
	}
	currentUsername, _ := caesar.New("").DecryptString(payload.Issuer)
	if currentUsername == "" {
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Token is wrong format", HttpStatusCode: fiber.StatusBadRequest})
	}
	localService.SetUsername(currentUsername)
	localService.SetDevicePlatform(payload.Data.Platform)
	if err = payload.Valid(); err != nil {
		switch {
		case errors.Is(err, jwt.ErrExpiredAtSoLarge):
			return response.NewError(constants.ReturnCode622TokenExpiredAtSoLarge, response.ErrorOptions{Data: "Token expired invalid", HttpStatusCode: fiber.StatusUnauthorized})
		case errors.Is(err, jwt.ErrPlatformIsNotSupported):
			return response.NewError(fiber.StatusUnauthorized, response.ErrorOptions{Data: "Platform is not supported", HttpStatusCode: fiber.StatusUnauthorized})
		default:
			logging.GetLogger().Error().Err(err).Msg("tokenAuthenticate")
			return response.NewError(constants.ReturnCode621TokenNotJWT, response.ErrorOptions{Data: "Token timeout", HttpStatusCode: fiber.StatusUnauthorized})
		}
	}
	queryOption := queries.NewOptions()
	queryOption.SetOnlyFields(localService.GetUserOnlyFields()...)
	user, err := queries.NewUser(ctx.Context()).GetByUsernameWithIsActive(currentUsername, true, queryOption)
	if err != nil {
		switch err.(*response.Error).Code {
		case fiber.StatusNotFound:
			return response.NewError(constants.ReturnCode605UserNotFound, response.ErrorOptions{Data: "This username does not exist.", HttpStatusCode: fiber.StatusUnauthorized})
		default:
			return err
		}
	}
	localService.SetUser(user)
	if err = jwtService.VerifyToken(token, parts, user.PublicKey); err != nil {
		return response.NewError(constants.ReturnCode620TokenWrongSignature, response.ErrorOptions{Data: "Token is wrong signature", HttpStatusCode: fiber.StatusUnauthorized})
	}
	queryOption.SetOnlyFields("devices.key_uuid", "devices.platform", "devices.active")
	uuid, err := queries.NewUUID(ctx.Context()).GetByUsername(currentUsername, queryOption)
	if err != nil {
		switch err.(*response.Error).Code {
		case fiber.StatusNotFound:
			return response.NewError(constants.ReturnCode460UUIDInvalid, response.ErrorOptions{Data: "UUID does not exists.", HttpStatusCode: fiber.StatusUnauthorized})
		default:
			return err
		}
	}
	uuidInfo := uuid.GetInfoByPlatform(payload.Data.Platform)
	if uuidInfo == nil || !uuidInfo.Active || uuidInfo.KeyUUID == "" {
		return response.NewError(constants.ReturnCode460UUIDInvalid, response.ErrorOptions{Data: "UUID does not exists", HttpStatusCode: fiber.StatusUnauthorized})
	}
	localService.SetDeviceID(uuidInfo.KeyUUID)
	localService.SetDeviceInfo(uuidInfo)
	return nil
}

func verifyHashHeaderV2(ctx *fiber.Ctx) error {
	requestHashHex := ctx.Get(headerHash)
	if requestHashHex == "" {
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Hash missing", HttpStatusCode: fiber.StatusUnauthorized})
	}
	requestHash, err := hex.DecodeString(requestHashHex)
	if err != nil {
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Hash wrong format", HttpStatusCode: fiber.StatusUnauthorized})
	}
	localService := local.New(ctx)
	hmacKey, err := aes128.GetKey(fmt.Sprintf("%s%v", localService.GetDeviceID(), localService.GetAPICode()))
	if err != nil {
		return response.NewError(fiber.StatusInternalServerError, response.ErrorOptions{HttpStatusCode: fiber.StatusUnauthorized})
	}
	contentType := ctx.Get(fiber.HeaderContentType)
	hmacTool := hmac.New(sha256.New, hmacKey)
	switch {
	case strings.HasPrefix(contentType, fiber.MIMEApplicationJSON):
		hmacTool.Write(ctx.Request().Body())
	case strings.HasPrefix(contentType, fiber.MIMEMultipartForm):
		hmacTool.Write([]byte(ctx.FormValue("data")))
	default:
		return response.NewError(fiber.StatusUnsupportedMediaType, response.ErrorOptions{Data: "Content-type is not supported", HttpStatusCode: fiber.StatusUnauthorized})
	}
	calculateHash := hmacTool.Sum(nil)
	if !hmac.Equal(requestHash, calculateHash) {
		return response.NewError(fiber.StatusUnauthorized, response.ErrorOptions{Data: "Hash is invalid", HttpStatusCode: fiber.StatusUnauthorized})
	}
	return nil
}

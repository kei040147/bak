package permission

import (
	"ws-selector/common/constants"
	"ws-selector/common/response"
	"ws-selector/utilities/local"

	"github.com/gofiber/fiber/v2"
)

func Required(ctx *fiber.Ctx) error {
	localStorage := local.New(ctx)
	user := localStorage.GetUser()
	if !user.Active {
		return response.NewError(constants.ReturnCode403UserUnActive, response.ErrorOptions{Data: "Forbidden! This user is not active."})
	}
	if !user.NotBlock {
		if user.DeletedAt != nil {
			return response.NewError(constants.ReturnCode616BlockByAdminDelete, response.ErrorOptions{Data: "Forbidden! This user is block by admin"})
		} else {
			return response.NewError(constants.ReturnCode604BlockByDisable, response.ErrorOptions{Data: "Forbidden! This user is disable by admin"})
		}
	}
	return ctx.Next()
}

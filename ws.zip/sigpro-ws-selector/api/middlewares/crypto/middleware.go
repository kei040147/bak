package crypto

import (
	"fmt"
	"strings"

	"ws-selector/common/configure"
	"ws-selector/common/logging"
	"ws-selector/common/response"
	"ws-selector/utilities/crypto/aes/aes128"
	"ws-selector/utilities/gzip"
	"ws-selector/utilities/local"

	"github.com/bytedance/sonic"
	"github.com/gofiber/fiber/v2"
)

var (
	DisableEncryptResponse bool
	DisableDecryptRequest  bool
)

var (
	logger = logging.GetLogger()
	cfg    = configure.GetConfig()
)

type encryptBody struct {
	Data string `form:"data" json:"data"`
}

func DecryptRequest(ctx *fiber.Ctx) error {
	if DisableDecryptRequest {
		return ctx.Next()
	}
	if cfg.Debug && ctx.Get("decrypt", "1") == "0" {
		return ctx.Next()
	}

	var requestBody encryptBody
	rawBody := ctx.Request().Body()
	if len(rawBody) < 1 {
		return ctx.Next()
	}
	if err := ctx.BodyParser(&requestBody); err != nil {
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Invalid request and/or insufficient data."})
	}
	if requestBody.Data == "" {
		ctx.Request().SetBody([]byte("{}"))
		return ctx.Next()
	}
	localStorage := local.New(ctx)
	aes128Tool, err := aes128.New(fmt.Sprintf("%s%v", localStorage.GetDeviceID(), localStorage.GetAPICode()))
	if err != nil {
		logger.Error().Err(err).Str("function", "DecryptRequest").Str("functionInline", "aes128.New").Msg("encrypt-middleware")
		return response.NewError(fiber.StatusInternalServerError)
	}
	bodyDecrypt, err := aes128Tool.Decrypt(requestBody.Data)
	if err != nil {
		logger.Error().Err(err).Str("data", requestBody.Data).Msg("decryptRequest AES128 decrypt failed")
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Invalid request and/or insufficient data."})
	}
	decompressData, err := gzip.New().Decompress(bodyDecrypt)
	if err != nil {
		logger.Error().Err(err).Str("data", requestBody.Data).Msg("decryptRequest gzip decompress failed")
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Invalid request and/or insufficient data."})
	}
	localStorage.SetRequestBody(decompressData)
	contentType := ctx.Get(fiber.HeaderContentType)
	switch {
	case strings.HasPrefix(contentType, fiber.MIMEApplicationJSON):
		ctx.Request().SetBody(decompressData)
		return ctx.Next()
	case strings.HasPrefix(contentType, fiber.MIMEMultipartForm):
		form, _ := ctx.MultipartForm()
		var rawData map[string]string
		if errUnmarshal := sonic.Unmarshal(decompressData, &rawData); errUnmarshal != nil {
			return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: "Invalid request and/or insufficient data. Field must type is string"})
		}
		multipartData := make(map[string][]string)
		for key, value := range rawData {
			multipartData[key] = []string{value}
		}
		form.Value = multipartData
		return ctx.Next()
	default:
		return response.NewError(fiber.StatusUnsupportedMediaType, response.ErrorOptions{Data: "Content-type is not supported"})
	}
}

func EncryptResponse(ctx *fiber.Ctx) error {
	useUuidKey := true
	if err := ctx.Next(); err != nil {
		_ = response.FiberErrorHandler(ctx, err)
		if e, ok := err.(*response.Error); ok && e.HttpStatusCode != fiber.StatusOK {
			useUuidKey = false
		}
	}
	localStorage := local.New(ctx)
	responseBody := ctx.Response().Body()
	localStorage.SetResponseBody(responseBody)
	if cfg.Debug && ctx.Get("encrypt", "1") == "0" {
		return nil
	}
	if DisableEncryptResponse {
		return nil
	}
	compressData := gzip.New().Compress(responseBody)
	encryptKey := fmt.Sprintf("%s%v", localStorage.GetDeviceID(), localStorage.GetAPICode())
	if !useUuidKey {
		encryptKey = fmt.Sprintf("%s%v", localStorage.GetUsername(), localStorage.GetAPICode())
	}
	aes128Tool, err := aes128.New(encryptKey)
	if err != nil {
		logger.Error().Err(err).Str("function", "EncryptResponse").Str("functionInline", "aes128.New").Msg("encrypt-middleware")
		return response.New(ctx, response.Options{Code: fiber.StatusInternalServerError})
	}
	bodyEncrypt, err := aes128Tool.Encrypt(compressData)
	if err != nil {
		logger.Error().Err(err).Msg("encryptResponse AES128 encrypt failed")
		return response.New(ctx, response.Options{Code: fiber.StatusInternalServerError})
	}
	encBody, _ := sonic.Marshal(encryptBody{Data: bodyEncrypt})
	ctx.Context().Response.SetBody(encBody)
	return nil
}

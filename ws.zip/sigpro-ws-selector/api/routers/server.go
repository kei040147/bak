package routers

import (
	serverCtrl "ws-selector/api/controllers/server"
	authMiddleware "ws-selector/api/middlewares/authenticate"
	cryptoMiddleware "ws-selector/api/middlewares/crypto"
	permissionMiddleware "ws-selector/api/middlewares/permission"
	"ws-selector/common/constants"
	"ws-selector/utilities/local"

	"github.com/gofiber/fiber/v2"
)

type Server interface {
	V1()
}

type server struct {
	router     fiber.Router
	controller serverCtrl.Controller
}

func NewServer(router fiber.Router) Server {
	return &server{router: router.Group("/servers"), controller: serverCtrl.New()}
}

func (r *server) GetInfoAPICode(ctx *fiber.Ctx) error {
	localService := local.New(ctx)
	localService.SetAPICode(constants.APICodeServerGetInfo)
	localService.SetUserOnlyFields("_id")
	return ctx.Next()
}

func (r *server) V1() {
	r.router.Use("/get-info", r.GetInfoAPICode)
	r.router.Use(
		cryptoMiddleware.EncryptResponse, authMiddleware.Authenticate, permissionMiddleware.Required, cryptoMiddleware.DecryptRequest,
	)
	r.router.Post("/get-info", r.controller.GetInfo)
}

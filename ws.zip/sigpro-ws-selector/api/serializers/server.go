package serializers

import (
	"ws-selector/common/request/validator"
	"ws-selector/common/response"

	"github.com/gofiber/fiber/v2"
)

type ServerGetInfoBodyValidate struct {
	Servers []string `json:"servers" validate:"required,min=1,unique,dive,server"`
}

func (v *ServerGetInfoBodyValidate) Validate() *response.Error {
	validateEngine := validator.GetValidateEngine()
	if err := validateEngine.Struct(v); err != nil {
		return response.NewError(fiber.StatusBadRequest, response.ErrorOptions{Data: validator.ParseValidateError(err)})
	}
	return nil
}

type ServerGetInfoResponseItem struct {
	Domain    string `json:"domain"`
	TokenType string `json:"token_type"`
	Server    string `json:"server"`
}

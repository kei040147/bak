package constants

const (
	ServerWsSgi     = "sgi"
	ServerWsMessage = "msg"
)

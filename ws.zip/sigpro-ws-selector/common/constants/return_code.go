package constants

const (
	ReturnCode100Continue              = 100 // RFC 7231, 6.2.1
	ReturnCode200OK                    = 200 // RFC 7231, 6.3.1
	ReturnCode201Created               = 201 // RFC 7231, 6.3.2
	ReturnCode204NoContent             = 204 // RFC 7231, 6.3.5
	ReturnCode300MultipleChoices       = 300 // RFC 7231, 6.4.1
	ReturnCode400BadRequest            = 400 // Invalid request and/or insufficient data
	ReturnCode401Unauthorized          = 401 // Authentication failed.
	ReturnCode403UserUnActive          = 403 // Forbidden! This user is not active.
	ReturnCode404DataNotfound          = 404 // Not Found!
	ReturnCode406NotAcceptable         = 406 // RFC 7231, 6.5.6
	ReturnCode409Conflict              = 409 // RFC 7231, 6.5.8
	ReturnCode412UserBlocked           = 412 // User has been blocked by whitelist
	ReturnCode415UnsupportedMediaType  = 415 // RFC 7231, 6.5.13
	ReturnCode423Locked                = 423 // Blocked.
	ReturnCode429TooManyRequest        = 429 // Too many request.
	ReturnCode460UUIDInvalid           = 460 // UUID does not exists
	ReturnCode461UserInvalid           = 461 // User does not exists
	ReturnCode462PermissionInvalid     = 462 // Permission is invalid
	ReturnCode500ServerError           = 500 // Server experiences some internal issues.
	ReturnCode600TransactionExpired    = 600 // Transaction has been expired.
	ReturnCode601OTPUsed               = 601 // OTP has been used
	ReturnCode602OTPExpire             = 602 // OTP has been expired
	ReturnCode603OTPWrong              = 603 // OTP code is wrong
	ReturnCode604BlockByDisable        = 604 // Block request because user has been disable by admin
	ReturnCode605UserNotFound          = 605 // This username does not exists.
	ReturnCode606VerifyInvalid         = 606 // Verify is invalid.
	ReturnCode611PolicyError           = 611 // Role permission error
	ReturnCode615DeviceNotPermission   = 615 // Device don't has permission.
	ReturnCode616DataNotAllow          = 616 // Data isn't allowed
	ReturnCode616BlockByAdminDelete    = 616 // Block request because user has been deleted by admin
	ReturnCode617DataInvalid           = 617 // Data is invalid
	ReturnCode617DenyByDisable         = 617 // Forbidden because user has been deleted or disable by admin
	ReturnCode618UserNotPermission     = 618 // Users don't has permission.
	ReturnCode619MasterPassword        = 619 // Users have master password
	ReturnCode620TokenWrongSignature   = 620
	ReturnCode621TokenNotJWT           = 621
	ReturnCode622TokenExpiredAtSoLarge = 622
)

const (
	JoinRoomReturnCode701RoomHasBeenLocked = 701
	JoinRoomReturnCode702RoomHasBeenEnded  = 702
	JoinRoomReturnCode703WrongPassword     = 703
)

package constants

const (
	APICodeServerGetInfo = 221
)

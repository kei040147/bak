package error

var (
	ErrResourceNotFound = "Resource not found"

	ErrTokenRequired     = "Token is required"
	ErrTokenWrongFormat  = "Token is wrong format"
	ErrTokenWrong        = "Token is wrong"
	ErrTokenExpired      = "Token is expired"
	ErrTokenValidateFail = "Token validate failed"
	ErrSessionIdBlank    = "sessionID is blank"

	ErrFieldWrongType = "Field wrong type"

	ErrSessionCreated  = "Session has been created"
	ErrSessionNotFound = "Session not found"

	ErrUserCreated  = "User has been created"
	ErrUserNotFound = "User not found"

	ErrUrlNotFound = "URL not found"

	ErrRoomHasBeenLocked = "Room has been locked"
	ErrRoomHasBeenEnded  = "Room has been ended"
	ErrWrongPassword     = "Wrong password"
)

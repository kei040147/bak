package configure

import (
	"fmt"
	"time"

	"github.com/caarlos0/env/v11"
	"github.com/joho/godotenv"
	"github.com/rs/zerolog/log"
)

var config *Configuration

type Configuration struct {
	Port                          string        `env:"PORT" envDefault:"8148"`
	Host                          string        `env:"HOST" envDefault:"0.0.0.0"`
	TokenType                     string        `env:"TOKEN_TYPE" envDefault:"Bearer"`
	MongoDBApiUri                 string        `env:"MONGODB_API_URI" envDefault:"mongodb://localhost:27017"`
	MongoDBApiName                string        `env:"MONGODB_API_NAME" envDefault:"db_api"`
	SgiWsSelectorAccessToken      string        `env:"SGI_WS_SELECTOR_ACCESS_TOKEN" envDefault:"!change_me!"`
	SgiWsSelectorDomain           string        `env:"SGI_WS_SELECTOR_DOMAIN" envDefault:"http://localhost:8149"`
	MsgWsSelectorAccessToken      string        `env:"MSG_WS_SELECTOR_ACCESS_TOKEN" envDefault:"!change_me!"`
	MsgWsSelectorDomain           string        `env:"MSG_WS_SELECTOR_DOMAIN" envDefault:"http://localhost:8158"`
	MongoDBRequestTimeout         time.Duration `env:"MONGODB_REQUEST_TIMEOUT" envDefault:"3m"`
	TokenIssueAtAllowDiffDuration time.Duration `env:"TOKEN_ISSUE_AT_ALLOW_DIFF_DURATION" envDefault:"5m"`
	TokenLimitTimeExpire          time.Duration `env:"TOKEN_LIMIT_TIME_EXPIRE" envDefault:"3h"`
	PaginationMaxItem             int64         `env:"PAGINATION_MAX_ITEM" envDefault:"50"`
	Debug                         bool          `env:"DEBUG" envDefault:"false"`
	ElasticAPMEnable              bool          `env:"ELASTIC_APM_ENABLE" envDefault:"false"`
	MongoAutoIndex                bool          `env:"MONGO_AUTO_INDEX" envDefault:"false"`
}

func (cfg Configuration) ServerAddress() string {
	return fmt.Sprintf("%s:%s", cfg.Host, cfg.Port)
}

func GetConfig() Configuration {
	if config == nil {
		_ = godotenv.Load()
		config = &Configuration{}
		if err := env.Parse(config); err != nil {
			log.Fatal().Err(err).Msg("Get Config Error")
		}
	}
	return *config
}

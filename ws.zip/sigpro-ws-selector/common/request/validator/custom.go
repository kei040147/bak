package validator

import (
	"ws-selector/common/constants"

	"github.com/go-playground/validator/v10"
)

var server = ValidateFunction{
	Tag: "server",
	Function: func(fl validator.FieldLevel) bool {
		value := fl.Field().String()
		mapCheck := map[string]struct{}{
			constants.ServerWsSgi: {}, constants.ServerWsMessage: {},
		}
		_, ok := mapCheck[value]
		return ok
	},
}

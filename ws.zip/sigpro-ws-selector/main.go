package main

import (
	"os"
	"os/signal"
	"syscall"

	"ws-selector/api/routers"
	"ws-selector/common/configure"
	"ws-selector/common/logging"
	"ws-selector/common/request/validator"
	"ws-selector/common/response"
	respErr "ws-selector/common/response/error"
	"ws-selector/database"
	jwt "ws-selector/utilities/jwt/client"

	"github.com/bytedance/sonic"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/recover"
	_ "go.uber.org/automaxprocs"
)

var cfg = configure.GetConfig()

func main() {
	logging.InitLogger()
	validator.InitValidateEngine()
	database.InitDatabase()
	jwt.InitSetting(cfg.TokenLimitTimeExpire, cfg.TokenIssueAtAllowDiffDuration)
	app := fiber.New(fiber.Config{
		ErrorHandler: response.FiberErrorHandler,
		JSONDecoder:  sonic.Unmarshal,
		JSONEncoder:  sonic.Marshal,
	})
	addMiddleware(app)
	addV1Route(app)
	handleURLNotFound(app)
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)
	go func() {
		if err := app.Listen(cfg.ServerAddress()); err != nil {
			logging.GetLogger().Error().Err(err).Str("function", "main").Str("functionInline", "app.Listen").Msg("Can't start server")
		}
		sigChan <- syscall.SIGTERM
	}()
	<-sigChan
	logging.GetLogger().Info().Msg("Shutting down...")
	_ = app.Shutdown()
}

func handleURLNotFound(app *fiber.App) {
	app.Use(func(ctx *fiber.Ctx) error {
		return response.New(ctx, response.Options{Code: fiber.StatusNotFound, Data: respErr.ErrUrlNotFound})
	})
}

func addMiddleware(app *fiber.App) {
	if cfg.ElasticAPMEnable {
		app.Use(logging.FiberApmMiddleware())
	} else {
		recoverConfig := recover.ConfigDefault
		recoverConfig.EnableStackTrace = cfg.Debug
		app.Use(recover.New(recoverConfig))
	}
	app.Use(logging.FiberLoggerMiddleware())
}

func addV1Route(app *fiber.App) {
	route := app.Group("/api/ws-selector/v1")
	routers.NewServer(route).V1()
}

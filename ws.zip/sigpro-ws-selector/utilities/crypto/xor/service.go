package xor

import (
	"encoding/base64"
	"encoding/binary"
	"math"
	"unsafe"

	"ws-selector/common/logging"
	"ws-selector/utilities/crypto"
)

var logger = logging.GetLogger()

type service struct {
	key    []byte
	lenKey int
}

func New(key interface{}) crypto.Service {
	keyByte := make([]byte, 0)
	if value, ok := key.([]byte); ok {
		keyByte = value
	} else if value, ok := key.(string); ok {
		keyByte = []byte(value)
	} else if value, ok := key.(int64); ok {
		intByte := make([]byte, unsafe.Sizeof(value))
		binary.LittleEndian.PutUint64(intByte, uint64(value))
		keyByte = intByte
	} else {
		logger.Fatal().Msg("type is not support")
	}
	return &service{key: keyByte, lenKey: len(keyByte)}
}

func (s *service) formatKey(dataLength int) []byte {
	ratio := int(math.Ceil(float64(dataLength) / float64(s.lenKey)))
	if ratio <= 1 {
		return s.key[:dataLength]
	}
	lenNewKey := ratio * s.lenKey
	newKey := make([]byte, 0, lenNewKey)
	for i := 0; i < lenNewKey; i += s.lenKey {
		copy(newKey[i:(i+s.lenKey-1)], s.key)
	}
	return newKey[:dataLength]
}

func (s *service) xor(input, key []byte) []byte {
	lenInput := len(input)
	output := make([]byte, lenInput)
	for i := 0; i < lenInput; i++ {
		output[i] = input[i] ^ key[i]
	}
	return output
}

func (s *service) EncryptToByte(raw []byte) (enc []byte, error error) {
	return s.xor(raw, s.formatKey(len(raw))), nil
}

func (s *service) DecryptFromByte(enc []byte) (raw []byte, error error) {
	return s.xor(enc, s.formatKey(len(enc))), nil
}

func (s *service) Encrypt(raw []byte) (enc string, error error) {
	cipherByte, err := s.EncryptToByte(raw)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(cipherByte), nil
}

func (s *service) Decrypt(enc string) (raw []byte, error error) {
	encByte, errDecode := base64.StdEncoding.DecodeString(enc)
	if errDecode != nil {
		logger.Error().Err(errDecode).Msg("XOR Decrypt decode text error")
		return nil, errDecode
	}
	return s.DecryptFromByte(encByte)
}

func (s *service) EncryptString(raw string) (enc string, error error) {
	return s.Encrypt([]byte(raw))
}

func (s *service) DecryptString(enc string) (raw string, error error) {
	rawByte, err := s.Decrypt(enc)
	if err != nil {
		return "", err
	}
	return string(rawByte), nil
}

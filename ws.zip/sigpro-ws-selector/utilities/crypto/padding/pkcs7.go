package padding

import (
	"bytes"
	"crypto/aes"
	"fmt"
)

type PKCS7Interface interface {
	Padding(data []byte) ([]byte, error)
	UnPadding(data []byte) ([]byte, error)
}

type pkcs7 struct {
	blockSize int
}

func NewPKCS7(blockSize int) PKCS7Interface {
	if blockSize < 1 {
		blockSize = aes.BlockSize
	}
	return &pkcs7{blockSize: blockSize}
}

func (s *pkcs7) Padding(data []byte) ([]byte, error) {
	dataLen := len(data)
	if data == nil || dataLen == 0 {
		return nil, fmt.Errorf("invalid PKCS7 data (empty or not padded)")
	}
	n := s.blockSize - (dataLen % s.blockSize)
	pb := make([]byte, dataLen+n)
	copy(pb, data)
	copy(pb[dataLen:], bytes.Repeat([]byte{byte(n)}, n))
	return pb, nil
}

func (s *pkcs7) UnPadding(data []byte) ([]byte, error) {
	dataLen := len(data)
	if data == nil || dataLen == 0 {
		return nil, fmt.Errorf("invalid PKCS7 data (empty or not padded)")
	}
	if dataLen%s.blockSize != 0 {
		return nil, fmt.Errorf("invalid padding on input")
	}
	c := data[dataLen-1]
	n := int(c)
	if n == 0 || n > dataLen {
		return nil, fmt.Errorf("invalid padding on input")
	}
	for i := 0; i < n; i++ {
		if data[dataLen-n+i] != c {
			return nil, fmt.Errorf("invalid padding on input")
		}
	}
	return data[:dataLen-n], nil
}

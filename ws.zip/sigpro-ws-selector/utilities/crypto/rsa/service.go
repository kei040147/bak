package rsa

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
)

func (s *service) GenerateRSAKeyPair() (privateKey string, publicKey string) {
	rsaPrivateKey, _ := rsa.GenerateKey(rand.Reader, RSAKeyLength)
	privateKeyDerBytes := x509.MarshalPKCS1PrivateKey(rsaPrivateKey)
	publicKeyDerBytes := x509.MarshalPKCS1PublicKey(&rsaPrivateKey.PublicKey)
	return base64.StdEncoding.EncodeToString(privateKeyDerBytes), base64.StdEncoding.EncodeToString(publicKeyDerBytes)
}

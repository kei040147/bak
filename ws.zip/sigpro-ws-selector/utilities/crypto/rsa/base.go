package rsa

const RSAKeyLength = 2048

type Service interface {
	GenerateRSAKeyPair() (privateKey string, publicKey string)
}

type service struct{}

func New() Service {
	return new(service)
}

package caesar

import (
	"strings"

	"ws-selector/utilities/crypto"
)

const defaultKey = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+=?"

type caesar struct {
	keyStr  string
	keyRune []rune
}

func New(key string) crypto.Service {
	if key == "" {
		key = defaultKey
	}
	return &caesar{keyStr: key, keyRune: []rune(key)}
}

func (s *caesar) mod(a, b int) int {
	return (a%b + b) % b
}

func (s *caesar) EncryptString(raw string) (enc string, error error) {
	runes := []rune(raw)
	textLen := len(raw)
	keyLen := len(s.keyStr)

	for i, char := range runes {
		val := char
		keyIndex := strings.IndexRune(s.keyStr, char)
		if keyIndex != -1 {
			index := s.mod(keyIndex+textLen, keyLen)
			val = s.keyRune[index]
		}
		runes[i] = val
	}
	return string(runes), nil
}

func (s *caesar) DecryptString(enc string) (raw string, error error) {
	runes := []rune(enc)
	textLen := len(enc)
	keyLen := len(s.keyStr)

	for i, char := range runes {
		val := char
		keyIndex := strings.IndexRune(s.keyStr, char)
		if keyIndex != -1 {
			index := s.mod(keyIndex-textLen, keyLen)
			val = s.keyRune[index]
		}
		runes[i] = val
	}
	return string(runes), nil
}

func (s *caesar) Encrypt(raw []byte) (enc string, error error) {
	return s.EncryptString(string(raw))
}

func (s *caesar) Decrypt(enc string) (raw []byte, error error) {
	rawStr, err := s.DecryptString(enc)
	return []byte(rawStr), err
}

func (s *caesar) EncryptToByte(raw []byte) (enc []byte, error error) {
	encStr, err := s.EncryptString(string(raw))
	return []byte(encStr), err
}

func (s *caesar) DecryptFromByte(enc []byte) (raw []byte, error error) {
	rawStr, err := s.DecryptString(string(enc))
	return []byte(rawStr), err
}

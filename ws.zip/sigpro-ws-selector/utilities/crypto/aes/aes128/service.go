package aes128

import (
	"fmt"

	"ws-selector/utilities/crypto"
	"ws-selector/utilities/crypto/aes"
	"ws-selector/utilities/hasher/sha1"
)

const (
	KeySize = 16
)

func New(key interface{}) (crypto.Service, error) {
	keyByte, err := GetKey(key)
	if err != nil {
		return nil, err
	}
	return aes.New(keyByte), nil
}

func GetKey(key interface{}) (keyByte []byte, err error) {
	switch value := key.(type) {
	case []byte:
		if len(value) != KeySize {
			return nil, fmt.Errorf("wrong key size")
		}
		return value, nil
	case string:
		if len(value) != KeySize {
			keyHash, errHash := sha1.New().Encode(value)
			if errHash != nil {
				return nil, errHash
			}
			return keyHash[:KeySize], nil
		}
		return []byte(value), nil
	default:
		return nil, fmt.Errorf("type is not support")
	}
}

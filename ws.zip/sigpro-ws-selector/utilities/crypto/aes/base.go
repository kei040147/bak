package aes

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"fmt"

	"ws-selector/utilities/crypto"
	"ws-selector/utilities/crypto/padding"
)

type service struct {
	key []byte
}

func New(key []byte) crypto.Service {
	return &service{key: key}
}

func (s *service) EncryptToByte(raw []byte) (enc []byte, error error) {
	byteMsg, errPkcs7 := padding.NewPKCS7(aes.BlockSize).Padding(raw)
	if errPkcs7 != nil {
		return nil, fmt.Errorf("PKCS7 padding error: %v", errPkcs7)
	}
	block, err := aes.NewCipher(s.key)
	if err != nil {
		return nil, fmt.Errorf("could not create new cipher: %v", err)
	}

	cipherText := make([]byte, len(byteMsg))
	iv := make([]byte, aes.BlockSize)
	stream := cipher.NewCBCEncrypter(block, iv)
	stream.CryptBlocks(cipherText, byteMsg)

	return cipherText, nil
}

func (s *service) DecryptFromByte(enc []byte) (raw []byte, error error) {
	block, err := aes.NewCipher(s.key)
	if err != nil {
		return nil, fmt.Errorf("could not create new cipher: %v", err)
	}

	if len(enc) < aes.BlockSize {
		return nil, fmt.Errorf("invalid ciphertext block size")
	}

	iv := make([]byte, aes.BlockSize)

	stream := cipher.NewCBCDecrypter(block, iv)
	stream.CryptBlocks(enc, enc)

	cipherTextUnPadding, errPKCS7 := padding.NewPKCS7(aes.BlockSize).UnPadding(enc)
	if errPKCS7 != nil {
		return nil, fmt.Errorf("PKCS7 unpadding error %v", errPKCS7)
	}

	return cipherTextUnPadding, nil
}

func (s *service) Encrypt(raw []byte) (enc string, error error) {
	cipherByte, err := s.EncryptToByte(raw)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(cipherByte), nil
}

func (s *service) Decrypt(enc string) (raw []byte, error error) {
	encByte, errDecode := base64.StdEncoding.DecodeString(enc)
	if errDecode != nil {
		return nil, errDecode
	}
	return s.DecryptFromByte(encByte)
}

func (s *service) EncryptString(raw string) (enc string, error error) {
	return s.Encrypt([]byte(raw))
}

func (s *service) DecryptString(enc string) (raw string, error error) {
	rawByte, err := s.Decrypt(enc)
	if err != nil {
		return "", err
	}
	return string(rawByte), nil
}

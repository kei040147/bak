package crypto

type Service interface {
	EncryptString(raw string) (enc string, error error)
	DecryptString(enc string) (raw string, error error)
	Encrypt(raw []byte) (enc string, error error)
	Decrypt(enc string) (raw []byte, error error)
	EncryptToByte(raw []byte) (enc []byte, error error)
	DecryptFromByte(enc []byte) (raw []byte, error error)
}

package client

import "time"

type service struct{}

var (
	limitTimeExpire time.Duration
	allowDiff       time.Duration
)

func New() Service {
	return &service{}
}

func InitSetting(limitTimeExpireToken, allowDiffDuration time.Duration) {
	limitTimeExpire = limitTimeExpireToken
	allowDiff = allowDiffDuration
}

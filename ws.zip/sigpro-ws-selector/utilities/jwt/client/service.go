package client

import (
	"crypto/x509"
	"encoding/base64"
	"strings"

	"github.com/golang-jwt/jwt/v5"
)

type Service interface {
	ParseUnverified(tokenString string) (token *jwt.Token, parts []string, payload *Payload, err error)
	VerifyToken(token *jwt.Token, parts []string, publicKey string) (err error)
}

func (s *service) ParseUnverified(tokenString string) (token *jwt.Token, parts []string, payload *Payload, err error) {
	var data Payload
	token, parts, err = jwt.NewParser().ParseUnverified(tokenString, &data)
	return token, parts, &data, err
}

func (s *service) VerifyToken(token *jwt.Token, parts []string, publicKey string) (err error) {
	if token.Method.Alg() != jwt.SigningMethodRS256.Alg() {
		return jwt.ErrTokenSignatureInvalid
	}
	pubKeyByte, err := base64.StdEncoding.DecodeString(publicKey)
	if err != nil {
		return jwt.ErrInvalidKey
	}
	var pubKey interface{}
	if pubKey, err = x509.ParsePKCS1PublicKey(pubKeyByte); err != nil {
		if pubKey, err = x509.ParsePKIXPublicKey(pubKeyByte); err != nil {
			return jwt.ErrNotEdPublicKey
		}
	}
	signature, err := jwt.NewParser().DecodeSegment(parts[2])
	if err != nil {
		return jwt.ErrTokenMalformed
	}
	if err = token.Method.Verify(strings.Join(parts[0:2], "."), signature, pubKey); err != nil {
		return jwt.ErrTokenSignatureInvalid
	}
	return nil
}

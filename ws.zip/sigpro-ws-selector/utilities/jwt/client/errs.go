package client

import "errors"

var (
	ErrExpiredAtSoLarge       = errors.New("expiredAt is so large")
	ErrPlatformIsNotSupported = errors.New("platform is not supported")
)

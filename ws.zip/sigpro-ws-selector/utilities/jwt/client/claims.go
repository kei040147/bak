package client

import (
	"github.com/golang-jwt/jwt/v5"
)

type PayloadData struct {
	Platform int `json:"platform"`
}

type Payload struct {
	jwt.RegisteredClaims
	Data PayloadData `json:"data"`
}

func (p Payload) Valid() (err error) {
	if p.ExpiresAt.Sub(p.IssuedAt.Time) > limitTimeExpire {
		return ErrExpiredAtSoLarge
	}
	p.RegisteredClaims.IssuedAt.Time = p.RegisteredClaims.IssuedAt.Add(-allowDiff)
	if err = jwt.NewValidator().Validate(p.RegisteredClaims); err != nil {
		return err
	}

	if _, ok := mapPlatform[p.Data.Platform]; !ok {
		return ErrPlatformIsNotSupported
	}
	return nil
}

package client

const (
	DevicePlatformAndroid = 1000
	DevicePlatformIos     = 2000
	DevicePlatformWindow  = 4000
	DevicePlatformLinux   = 5000
	DevicePlatformMac     = 6000
	DevicePlatformWeb     = 8000
	DevicePlatformIpad    = 10000
	DevicePlatformTablet  = 11000
)

var mapPlatform = map[int]struct{}{
	DevicePlatformAndroid: {}, DevicePlatformIos: {}, DevicePlatformWindow: {}, DevicePlatformLinux: {},
	DevicePlatformMac: {}, DevicePlatformWeb: {}, DevicePlatformIpad: {}, DevicePlatformTablet: {},
}

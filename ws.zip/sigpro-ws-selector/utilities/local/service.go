package local

import (
	"ws-selector/database/mongo/models"

	"github.com/bytedance/sonic"
	"github.com/gofiber/fiber/v2"
)

func (s service) SetStatusCode(value int) {
	s.context.Locals(KeyStatusCode, value)
}

func (s service) GetStatusCode() int {
	if value, ok := s.context.Locals(KeyStatusCode).(int); ok {
		return value
	}
	return fiber.StatusInternalServerError
}

func (s service) SetHTTPCode(value int) {
	s.context.Locals(KeyHTTPCode, value)
}

func (s service) GetHTTPCode() int {
	if value, ok := s.context.Locals(KeyHTTPCode).(int); ok {
		return value
	}
	return fiber.StatusInternalServerError
}

func (s service) SetResponseBody(value []byte) {
	s.context.Locals(KeyResponseBody, value)
}

func (s service) GetResponseBody() string {
	if value, ok := s.context.Locals(KeyResponseBody).([]byte); ok {
		if _, exist := apiPathClearData[s.context.Path()]; exist {
			rawData := make(map[string]interface{})
			_ = sonic.Unmarshal(value, &rawData)
			delete(rawData, "data")
			value, _ = sonic.Marshal(rawData)
		}
		return string(value)
	}
	return "{}"
}

func (s service) SetRequestBody(value []byte) {
	s.context.Locals(KeyRequestBody, value)
}

func (s service) GetRequestBody() string {
	if value, ok := s.context.Locals(KeyRequestBody).([]byte); ok {
		return string(value)
	}
	return "{}"
}

func (s service) SetUsername(value string) {
	s.context.Locals(KeyUsername, value)
}

func (s service) GetUsername() string {
	if value, ok := s.context.Locals(KeyUsername).(string); ok {
		return value
	}
	return ""
}

func (s service) SetUserPolicyRoleName(value string) {
	s.context.Locals(KeyPolicyRoleName, value)
}

func (s service) GetUserPolicyRoleName() string {
	if value, ok := s.context.Locals(KeyPolicyRoleName).(string); ok {
		return value
	}
	return ""
}

func (s service) SetDeviceID(value string) {
	s.context.Locals(KeyDeviceID, value)
}

func (s service) GetDeviceID() string {
	if value, ok := s.context.Locals(KeyDeviceID).(string); ok {
		return value
	}
	return ""
}

func (s service) SetDevicePlatform(value int) {
	s.context.Locals(KeyDevicePlatform, value)
}

func (s service) GetDevicePlatform() int {
	if value, ok := s.context.Locals(KeyDevicePlatform).(int); ok {
		return value
	}
	return unknownPlatform
}

func (s service) SetUser(value *models.User) {
	s.context.Locals(KeyUser, value)
}

func (s service) GetUser() *models.User {
	if value, ok := s.context.Locals(KeyUser).(*models.User); ok {
		return value
	}
	return nil
}

func (s service) SetDeviceInfo(value *models.UUIDInfo) {
	s.context.Locals(KeyDeviceInfo, value)
}

func (s service) GetDeviceInfo() *models.UUIDInfo {
	if value, ok := s.context.Locals(KeyDeviceInfo).(*models.UUIDInfo); ok {
		return value
	}
	return nil
}

func (s service) SetAPICode(value int) {
	s.context.Locals(KeyAPICode, value)
}

func (s service) GetAPICode() int {
	if value, ok := s.context.Locals(KeyAPICode).(int); ok {
		return value
	}
	return 0
}

func (s service) GetReturnCode() int {
	return s.GetAPICode()*returnCodeMultiplier + s.GetStatusCode()
}

func (s service) SetUserOnlyFields(fields ...string) {
	onlyFields := defaultUserOnlyFields
	for _, field := range fields {
		if _, ok := mapDefaultUserOnlyFields[field]; !ok {
			onlyFields = append(onlyFields, field)
		}
	}
	s.context.Locals(KeyUserOnlyFields, onlyFields)
}

func (s service) GetUserOnlyFields() []string {
	fields, ok := s.context.Locals(KeyUserOnlyFields).([]string)
	if !ok {
		return defaultUserOnlyFields
	}
	return fields
}

func (s service) SetExtraBody(value []byte) {
	s.context.Locals(KeyExtraBody, value)
}

func (s service) GetExtraBody() string {
	if value, ok := s.context.Locals(KeyExtraBody).([]byte); ok {
		return string(value)
	}
	return "{}"
}

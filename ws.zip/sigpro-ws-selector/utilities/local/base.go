package local

import (
	"ws-selector/database/mongo/models"

	"github.com/gofiber/fiber/v2"
)

type Service interface {
	GetStatusCode() int
	GetHTTPCode() int
	GetResponseBody() string
	GetRequestBody() string
	GetUsername() string
	GetUserPolicyRoleName() string
	GetDeviceID() string
	GetDevicePlatform() int
	GetUser() *models.User
	GetDeviceInfo() *models.UUIDInfo
	GetAPICode() int
	GetReturnCode() int
	GetUserOnlyFields() []string
	GetExtraBody() string
	SetUsername(value string)
	SetUserPolicyRoleName(value string)
	SetDeviceID(value string)
	SetStatusCode(value int)
	SetHTTPCode(value int)
	SetResponseBody(value []byte)
	SetRequestBody(value []byte)
	SetDevicePlatform(value int)
	SetUser(value *models.User)
	SetDeviceInfo(value *models.UUIDInfo)
	SetAPICode(value int)
	SetUserOnlyFields(fields ...string)
	SetExtraBody(value []byte)
}

const (
	KeyHTTPCode       = "httpCode"
	KeyStatusCode     = "statusCode"
	KeyRequestBody    = "requestBody"
	KeyResponseBody   = "responseBody"
	KeyUsername       = "username"
	KeyDeviceID       = "deviceID"
	KeyDevicePlatform = "devicePlatform"
	KeyUser           = "user"
	KeyDeviceInfo     = "deviceInfo"
	KeyAPICode        = "apiCode"
	KeyPolicyRoleName = "policyRoleName"
	KeyUserOnlyFields = "userOnlyFields"
	KeyExtraBody      = "extraBody"
)

const (
	unknownPlatform      = 3999
	returnCodeMultiplier = 1000
)

var apiPathClearData = map[string]struct{}{
	"/api/msg-api/v1/offline/get/": {}, "/api/msg-api/v1/offline/get": {},
	"/api/msg-api/v1/save-message/get/": {}, "/api/msg-api/v1/save-message/get": {},
}

var (
	defaultUserOnlyFields    = []string{"sip_id", "_id", "active", "new_rule", "public_key", "deleted_at"}
	mapDefaultUserOnlyFields = map[string]struct{}{
		"sip_id":     {},
		"_id":        {},
		"active":     {},
		"new_rule":   {},
		"public_key": {},
		"deleted_at": {},
	}
)

type service struct {
	context *fiber.Ctx
}

func New(ctx *fiber.Ctx) Service {
	return &service{context: ctx}
}

package sha1

import (
	"crypto/sha1" //nolint:gosec

	"ws-selector/utilities/hasher"
)

func New() hasher.Service {
	return hasher.New(sha1.New()) //nolint:gosec
}

package service_ws_selector

import (
	"net/url"
	"time"

	"ws-selector/common/logging"
)

const (
	defaultTimeout  = 30 * time.Second
	defaultMaxRetry = 3
)

var (
	logger        = logging.GetLogger()
	defaultOption = Option{MaxRetry: defaultMaxRetry, DefaultTimeout: defaultTimeout}
)

type Service interface {
	GetServerInfoByUsername(serviceSelectorPath, username string) (int, *ServerInfo, error)
}

type Option struct {
	AccessToken    string
	DefaultTimeout time.Duration
	MaxRetry       int
}

type service struct {
	baseURL *url.URL
	opt     Option
}

func New(baseURL string, opts ...Option) Service {
	apiURL, err := url.Parse(baseURL)
	if err != nil {
		logger.Fatal().Err(err).Str("function", "New").Str("functionInline", "url.Parse").Msg("service_ws_selector")
	}
	serv := service{baseURL: apiURL, opt: defaultOption}
	if len(opts) != 0 {
		if opts[0].MaxRetry != 0 {
			serv.opt.MaxRetry = opts[0].MaxRetry
		}
		if opts[0].DefaultTimeout != 0 {
			serv.opt.DefaultTimeout = opts[0].DefaultTimeout
		}
		serv.opt.AccessToken = opts[0].AccessToken
	}
	return &serv
}

type ServerInfo struct {
	Data struct {
		Domain    string `json:"domain"`
		TokenType string `json:"token_type"`
	} `json:"data"`
}

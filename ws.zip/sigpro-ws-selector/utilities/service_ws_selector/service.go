package service_ws_selector

import (
	"ws-selector/common/response"

	"github.com/bytedance/sonic"
	"github.com/gofiber/fiber/v2"
)

func (s *service) GetServerInfoByUsername(serviceSelectorPath, username string) (int, *ServerInfo, error) {
	code, res, err := s.buildRequest(
		fiber.MethodPost, serviceSelectorPath,
		fiber.Map{
			"username": username,
		},
	)
	if code != fiber.StatusOK {
		logger.Error().Err(err).Bytes("resp", res).Int("statusCode", code).Str("function", "GetServerInfoByUsername").Str("function-inline", "code != fiber.StatusOK").Msg("service_ws_selector")
		return code, nil, err
	}
	var respData ServerInfo
	if err = sonic.Unmarshal(res, &respData); err != nil {
		logger.Error().Err(err).Str("function", "GetServerInfoByUsername").Str("function-inline", "sonic.Unmarshal").Msg("service_ws_selector")
		return code, nil, response.NewError(fiber.StatusInternalServerError)
	}
	return code, &respData, nil
}

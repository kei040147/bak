package service_ws_selector

import (
	"net/url"

	"github.com/bytedance/sonic"
	"github.com/gofiber/fiber/v2"
)

func (s *service) buildFullPath(apiPath string) string {
	fullPathURL := s.baseURL.ResolveReference(&url.URL{Path: apiPath})
	fullPath, _ := url.QueryUnescape(fullPathURL.String())
	return fullPath
}

func (s *service) buildAgent(method, path string) (*fiber.Agent, error) {
	agent := fiber.AcquireAgent()
	agent.Reuse()
	agent.Request().Header.SetMethod(method)
	agent.Request().SetRequestURI(s.buildFullPath(path))
	agent.Request().Header.SetContentType(fiber.MIMEApplicationJSON)
	agent.Request().Header.Set(fiber.HeaderAuthorization, s.opt.AccessToken)
	agent = agent.JSONDecoder(sonic.Unmarshal).JSONEncoder(sonic.Marshal)

	if err := agent.Parse(); err != nil {
		return nil, err
	}
	return agent, nil
}

func (s *service) buildRequest(method, path string, reqBody map[string]interface{}) (code int, body []byte, err error) {
	if reqBody != nil {
		bodyByte, _ := sonic.Marshal(reqBody)
		return s.buildRequestBodyRaw(method, path, bodyByte)
	}
	return s.buildRequestBodyRaw(method, path, nil)
}

func (s *service) buildRequestBodyRaw(method, path string, reqBody []byte) (code int, body []byte, err error) {
	agent, err := s.buildAgent(method, path)
	if err != nil {
		return code, body, err
	}
	if reqBody != nil {
		agent = agent.Body(reqBody)
	}
	defer fiber.ReleaseAgent(agent)
	errs := make([]error, 0)
	for i := 0; i < s.opt.MaxRetry; i++ {
		code, body, errs = agent.Bytes()
		if fiber.StatusOK <= code && code < fiber.StatusInternalServerError {
			break
		}
		logger.Error().Interface("errs", errs).Str("urlPath", path).Interface("resp", string(body)).
			Int("statusCode", code).Int("retry-count", i+1).Str("function", "buildRequestBodyRaw").Msg("service_ws_selector")
	}
	if len(errs) > 0 {
		err = errs[0]
	}
	return code, body, err
}

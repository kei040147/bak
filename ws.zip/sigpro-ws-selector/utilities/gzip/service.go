package gzip

import (
	"bytes"
	"compress/gzip"
	"io"
)

type Service interface {
	Compress(raw []byte) []byte
	Decompress(raw []byte) ([]byte, error)
}

type service struct{}

func New() Service {
	return &service{}
}

func (s *service) Compress(raw []byte) []byte {
	buffer := bytes.Buffer{}
	writer := gzip.NewWriter(&buffer)
	_, _ = writer.Write(raw)
	_ = writer.Close()
	return buffer.Bytes()
}

func (s *service) Decompress(raw []byte) ([]byte, error) {
	reader, errReader := gzip.NewReader(bytes.NewReader(raw))
	if errReader != nil {
		return nil, errReader
	}
	defer func(reader *gzip.Reader) {
		if err := reader.Close(); err != nil {
			return
		}
	}(reader)
	return io.ReadAll(reader)
}

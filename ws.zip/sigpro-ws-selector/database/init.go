package database

import (
	"ws-selector/database/mongo"
)

func InitDatabase() {
	mongo.InitDatabase()
}

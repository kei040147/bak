package queries

import (
	"context"

	"ws-selector/common/response"
	"ws-selector/database/mongo"
	"ws-selector/database/mongo/models"

	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/bson"
	mongoDriver "go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type UUIDQuery interface {
	GetByUsername(username string, opts ...OptionsQuery) (uuid *models.UUID, errResp error)
}

type uuidQuery struct {
	collection *mongoDriver.Collection
	context    context.Context
}

func NewUUID(ctx context.Context) UUIDQuery {
	return &uuidQuery{
		collection: mongo.NewUtilityService().GetUUIDCollection(),
		context:    ctx,
	}
}

func (s *uuidQuery) GetByUsername(username string, opts ...OptionsQuery) (*models.UUID, error) {
	opt := NewOptions()
	if len(opts) > 0 {
		opt = opts[0]
	}
	optFind := options.FindOne()
	optFind.SetProjection(opt.QueryOnlyField())
	var data models.UUID
	ctx, cancel := timeoutFunc(s.context)
	defer cancel()
	if err := s.collection.FindOne(ctx, bson.M{"sip_id": username}, optFind).Decode(&data); err != nil {
		if err == mongoDriver.ErrNoDocuments {
			return nil, response.NewError(fiber.StatusNotFound, response.ErrorOptions{Data: "UUID not found"})
		}
		logger.Error().Err(err).Str("function", "GetByUsername").Str("functionInline", "q.collection.FindOne.Decode").Msg("uuidQuery")
		return nil, response.NewError(fiber.StatusInternalServerError)
	}
	return &data, nil
}

package queries

import (
	"context"

	"ws-selector/common/response"
	respErr "ws-selector/common/response/error"
	"ws-selector/database/mongo"
	"ws-selector/database/mongo/models"

	"github.com/gofiber/fiber/v2"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	mongoDriver "go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type UserQuery interface {
	GetByUsernameWithIsActive(username string, isActive bool, opts ...OptionsQuery) (user *models.User, errRes error)
	GetByIds(ids []primitive.ObjectID, opts ...OptionsQuery) (users []models.User, err error)
}

type userQuery struct {
	collection *mongoDriver.Collection
	context    context.Context
}

func NewUser(ctx context.Context) UserQuery {
	return &userQuery{
		collection: mongo.NewUtilityService().GetUserCollection(),
		context:    ctx,
	}
}

func (q *userQuery) GetByUsernameWithIsActive(username string, isActive bool, opts ...OptionsQuery) (*models.User, error) {
	opt := NewOptions()
	if len(opts) > 0 {
		opt = opts[0]
	}
	var data models.User
	optFind := &options.FindOneOptions{Projection: opt.QueryOnlyField()}
	ctx, cancel := timeoutFunc(q.context)
	defer cancel()
	if err := q.collection.FindOne(ctx, bson.M{"sip_id": username, "active": isActive}, optFind).Decode(&data); err != nil {
		if err == mongoDriver.ErrNoDocuments {
			return nil, response.NewError(fiber.StatusNotFound, response.ErrorOptions{Data: respErr.ErrUserNotFound})
		}
		logger.Error().Err(err).Str("function", "GetByUsernameWithIsActive").Str("functionInline", "q.collection.FindOne.Decode").Msg("userQuery")
		return nil, response.NewError(fiber.StatusInternalServerError)
	}
	return &data, nil
}

func (q *userQuery) GetByIds(ids []primitive.ObjectID, opts ...OptionsQuery) (users []models.User, err error) {
	opt := NewOptions()
	if len(opts) > 0 {
		opt = opts[0]
	}
	optFind := &options.FindOptions{
		Projection: opt.QueryOnlyField(),
	}
	ctx, cancel := timeoutFunc(q.context)
	defer cancel()
	cursor, err := q.collection.Find(ctx, bson.M{"_id": bson.M{"$in": ids}}, optFind)
	if err != nil {
		logger.Error().Err(err).Str("function", "GetByIds").Str("functionInline", "q.collection.Find").Msg("userQuery")
		return nil, response.NewError(fiber.StatusInternalServerError)
	}
	if err = cursor.All(ctx, &users); err != nil {
		logger.Error().Err(err).Str("function", "GetByIds").Str("functionInline", "cursor.All").Msg("userQuery")
		return nil, response.NewError(fiber.StatusInternalServerError)
	}
	return users, nil
}

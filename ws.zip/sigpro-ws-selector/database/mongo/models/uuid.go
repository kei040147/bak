package models

type UUIDInfo struct {
	KeyUUID  string `bson:"key_uuid"`
	Platform int    `bson:"platform"`
	Active   bool   `bson:"active"`
}

type UUID struct {
	Username string      `bson:"sip_id"`
	Devices  [4]UUIDInfo `bson:"devices"`
}

func (m *UUID) CollectionName() string {
	return "uuid"
}

func (m *UUID) GetInfoByPlatformAndKeyUUID(platform int, keyUUID string) *UUIDInfo {
	for _, info := range m.Devices {
		if info.KeyUUID == keyUUID && info.Platform == platform {
			return &info
		}
	}
	return nil
}

func (m *UUID) GetInfoByPlatform(platform int) *UUIDInfo {
	for _, info := range m.Devices {
		if info.Platform == platform {
			return &info
		}
	}
	return nil
}

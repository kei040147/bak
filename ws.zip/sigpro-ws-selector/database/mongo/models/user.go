package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type User struct {
	DeletedAt      *time.Time         `bson:"deleted_at"`
	Username       string             `bson:"sip_id"`
	Alias          string             `bson:"alias"`
	PublicKey      string             `bson:"public_key"`
	AvatarUrl      string             `bson:"avatar_url"`
	AvatarChecksum string             `bson:"avatar_checksum"`
	Active         bool               `bson:"active"`
	NotBlock       bool               `bson:"new_rule"`
	Id             primitive.ObjectID `bson:"_id"`
}

func (m *User) CollectionName() string {
	return "users"
}

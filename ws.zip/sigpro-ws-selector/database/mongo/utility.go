package mongo

import (
	"context"

	mongoModels "ws-selector/database/mongo/models"

	"go.mongodb.org/mongo-driver/mongo"
)

type UtilityService interface {
	getApiDB() (db *mongo.Database)
	GetContextTimeout(ctx context.Context) (context.Context, context.CancelFunc)
	GetUserCollection() (coll *mongo.Collection)
	GetUUIDCollection() (coll *mongo.Collection)
}

type utilityService struct{}

func NewUtilityService() UtilityService {
	service := utilityService{}
	return &service
}

func (s *utilityService) GetContextTimeout(ctx context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(ctx, cfg.MongoDBRequestTimeout)
}

func (s *utilityService) getApiDB() (db *mongo.Database) {
	return apiDBClient.Database(cfg.MongoDBApiName)
}

func (s *utilityService) GetUserCollection() (coll *mongo.Collection) {
	return s.getApiDB().Collection(new(mongoModels.User).CollectionName())
}

func (s *utilityService) GetUUIDCollection() (coll *mongo.Collection) {
	return s.getApiDB().Collection(new(mongoModels.UUID).CollectionName())
}

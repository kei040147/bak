# Websocket Selector

## Environment variable

| Environment                        | Default                   | Separator |
|------------------------------------|---------------------------|-----------|
| HOST                               | 0.0.0.0                   |           |
| PORT                               | 8148                      |           |
| TOKEN_TYPE                         | Bearer                    |           |
| DEBUG                              | false                     |           |
| MONGODB_API_URI                    | mongodb://localhost:27017 |           |
| MONGODB_API_NAME                   | db_api                    |           |
| MONGODB_REQUEST_TIMEOUT            | 3m                        |           |
| TOKEN_LIMIT_TIME_EXPIRE            | 3h                        |           |
| ELASTIC_APM_ENABLE                 | false                     |           |
| PAGINATION_MAX_ITEM                | 50                        |           |
| MONGO_AUTO_INDEX                   | false                     |           |
| SGI_WS_SELECTOR_ACCESS_TOKEN       | !change_me!               |           |
| SGI_WS_SELECTOR_DOMAIN             | http://localhost:8149     |           |
| MSG_WS_SELECTOR_ACCESS_TOKEN       | !change_me!               |           |
| MSG_WS_SELECTOR_DOMAIN             | http://localhost:8158     |           |
| TOKEN_ISSUE_AT_ALLOW_DIFF_DURATION | 5m                        |           |

### Elastic APM

| Environment                 | Example               |
|-----------------------------|-----------------------|
| ELASTIC_APM_CAPTURE_BODY    | all                   |
| ELASTIC_APM_ENVIRONMENT     | development           |
| ELASTIC_APM_SERVICE_VERSION | 1.0.0                 |
| ELASTIC_APM_SERVICE_NAME    | sigpro-ws-selector    |
| ELASTIC_APM_SECRET_TOKEN    | xxxxxx                |
| ELASTIC_APM_SERVER_URL      | http://localhost:8200 |

---

## Develop

### Option 1: AIR

#### Install AIR to hot-reload

```shell
curl -sSfL https://raw.githubusercontent.com/cosmtrek/air/master/install.sh | sh -s
```

file config air: `.air.toml`

#### Add environment variable

update field full_bin in config

```
full_bin = "<envirnoment-variable> sh -c ./tmp/main"
```

example:

```
full_bin = "DEBUG=true sh -c ./tmp/main"
```

#### Run

```shell
air
```

### Option 2: Golang Run

```shell
go run main
```

package bridge

import (
	"net/http"

	"mini-app-ai-ws-gateway/common/local"
	"mini-app-ai-ws-gateway/common/logging"
	"mini-app-ai-ws-gateway/controller/bridge_socket"
	"mini-app-ai-ws-gateway/utilities/bridge_socket_hub"
)

type Controller interface {
	ConnectWebSocket(w http.ResponseWriter, r *http.Request)
}

type controller struct {
	serv serviceInterface
}

func NewController() Controller {
	return &controller{serv: newService()}
}

func (ctrl *controller) ConnectWebSocket(w http.ResponseWriter, r *http.Request) {
	localService, _ := local.GetFromContext(r.Context())
	conn, err := ctrl.serv.GetUpgradeTool().Upgrade(w, r, nil)
	if err != nil {
		logging.GetLogger().Error().Err(err).Str("function", "ConnectWebSocket").
			Str("functionInline", "ctrl.serv.GetUpgradeTool().Upgrade").Msg("controller-bridge")
		localService.SetExtraBody(err.Error())
		return
	}
	if err = bridge_socket_hub.GetHub().Register(
		bridge_socket_hub.ClientInfo{
			Label: localService.GetBridgeLabel(), Identity: localService.GetBridgeIdentity(),
		},
		conn,
	); err != nil {
		logging.GetLogger().Error().Err(err).Str("function", "ConnectWebSocket").
			Str("functionInline", "bridge_socket_hub.GetHub().Register").Msg("controller-bridge")
		return
	}
	bridge_socket.New().ConnectionHandler(conn, false, nil)
	localService.SetHTTPCode(http.StatusSwitchingProtocols)
	localService.SetStatusCode(http.StatusOK)
}

package bridge

import (
	"net/http"

	"github.com/lesismal/nbio/nbhttp/websocket"
	"mini-app-ai-ws-gateway/common/logging"
	"mini-app-ai-ws-gateway/controller/bridge_socket"
)

type serviceInterface interface {
	GetUpgradeTool() *websocket.Upgrader
}

type service struct {
	upgradeTool *websocket.Upgrader
}

func newService() serviceInterface {
	upgradeTool := websocket.NewUpgrader()
	socketHandler := bridge_socket.New()
	upgradeTool.CheckOrigin = func(r *http.Request) bool { return true }
	upgradeTool.SetPingHandler(func(conn *websocket.Conn, data string) {
		if err := socketHandler.HandlePing(conn, data); err != nil {
			logging.GetLogger().Error().Err(err).Interface("function", "newService").
				Str("functionInline", "socketHandler.HandlePing").Msg("bridge-controller")
		}
	})
	upgradeTool.OnMessage(func(conn *websocket.Conn, messageType websocket.MessageType, data []byte) {
		dataCopy := make([]byte, len(data))
		copy(dataCopy, data)
		if err := socketHandler.HandlePacket(conn, messageType, dataCopy); err != nil {
			logging.GetLogger().Error().Err(err).Interface("function", "newService").
				Str("functionInline", "socketHandler.HandlePacket").Msg("bridge-controller")
		}
	})
	upgradeTool.OnClose(func(conn *websocket.Conn, err error) {
		socketHandler.ConnectionHandler(conn, true, err)
	})
	return &service{
		upgradeTool: upgradeTool,
	}
}

func (s *service) GetUpgradeTool() *websocket.Upgrader {
	return s.upgradeTool
}

package user

import (
	"net/http"

	"mini-app-ai-ws-gateway/common/local"
	"mini-app-ai-ws-gateway/common/logging"
	"mini-app-ai-ws-gateway/controller/user_socket"
	"mini-app-ai-ws-gateway/database/mongo/queries"
	"mini-app-ai-ws-gateway/utilities/user_socket_hub"
)

type Controller interface {
	ConnectWebSocket(w http.ResponseWriter, r *http.Request)
}

type controller struct {
	serv serviceInterface
}

func NewController() Controller {
	return &controller{serv: newService()}
}

func (ctrl *controller) ConnectWebSocket(w http.ResponseWriter, r *http.Request) {
	localService, _ := local.GetFromContext(r.Context())
	conn, err := ctrl.serv.GetUpgradeTool().Upgrade(w, r, nil)
	if err != nil {
		logging.GetLogger().Error().Err(err).Str("function", "ConnectWebSocket").
			Str("functionInline", "ctrl.serv.GetUpgradeTool().Upgrade").Msg("controller-user")
		localService.SetExtraBody(err.Error())
		return
	}
	currentUsername := localService.GetUsername()
	if err = user_socket_hub.GetHub().Register(
		user_socket_hub.ClientInfo{
			Username: currentUsername, Platform: localService.GetDevicePlatform(),
		},
		conn,
	); err != nil {
		logging.GetLogger().Error().Err(err).Str("function", "ConnectWebSocket").
			Str("functionInline", "user_socket_hub.GetHub().Register").Msg("controller-user")
		return
	}
	user_socket.New().ConnectionHandler(conn, false, nil)
	localService.SetHTTPCode(http.StatusSwitchingProtocols)
	localService.SetStatusCode(http.StatusOK)
	if err = queries.NewWsSessionQuery(r.Context()).DeleteBySessionKey(r.URL.Query().Get("session_key")); err != nil {
		logging.GetLogger().Error().Err(err).Str("function", "ConnectWebSocket").
			Str("functionInline", "queries.NewWsSessionQuery(r.Context()).DeleteBySessionKey").Msg("controller-user")
		localService.SetExtraBody(err.Error())
	}
}

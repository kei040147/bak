package authenticate

import (
	"errors"
	"net/http"
	"strconv"

	"mini-app-ai-ws-gateway/common/configure"
	"mini-app-ai-ws-gateway/common/constants"
	"mini-app-ai-ws-gateway/common/local"
	"mini-app-ai-ws-gateway/common/response"
	"mini-app-ai-ws-gateway/database/mongo/models"
	"mini-app-ai-ws-gateway/database/mongo/queries"
)

var cfg = configure.GetConfig()

func WebsocketUserAuthenticate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		username, sessionKey := r.URL.Query().Get("username"), r.URL.Query().Get("session_key")
		localService, _ := local.GetFromContext(r.Context())
		localService.SetUsername(username)
		platform, _ := strconv.Atoi(r.URL.Query().Get("platform"))
		localService.SetDevicePlatform(platform)
		if _, ok := constants.MapValidPlatforms[platform]; !ok {
			response.Write(r.Context(), response.Options{
				HttpStatusCode: http.StatusUnauthorized,
				Data:           "Invalid platform",
			})
			return
		}

		queryOption := queries.NewOptions()
		queryOption.SetOnlyFields("_id")
		if _, err := queries.NewWsSessionQuery(r.Context()).GetByUsernameSessionKeyAndPlatform(username, sessionKey, platform, queryOption); err != nil {
			if e := new(response.Error); errors.As(err, &e) && e.Code == http.StatusNotFound {
				response.Write(r.Context(), response.Options{
					HttpStatusCode: http.StatusUnauthorized,
					Data:           "Session not found",
				})
				return
			}
			response.Write(r.Context(), response.Options{
				HttpStatusCode: http.StatusInternalServerError,
				Data:           "Internal server error",
			})
			return
		}

		user, err := queries.NewUser(r.Context()).GetByUsername(username, queryOption)
		if err != nil {
			if e := new(response.Error); errors.As(err, &e) && e.Code == http.StatusNotFound {
				response.Write(r.Context(), response.Options{
					HttpStatusCode: http.StatusUnauthorized,
					Data:           "User not found",
				})
				return
			}
			response.Write(r.Context(), response.Options{
				HttpStatusCode: http.StatusInternalServerError,
				Data:           "Internal server error",
			})
			return
		}
		localService.SetUser(&models.User{
			Username: username, Id: user.Id,
		})
		next.ServeHTTP(w, r)
	})
}

func WebsocketBridgeAuthenticate(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		secretKey := r.Header.Get(constants.HeaderAuthorization)
		if secretKey != cfg.BridgeServiceSecretKey {
			response.Write(r.Context(), response.Options{
				Code: http.StatusUnauthorized,
				Data: "Secret key is wrong",
			})
			return
		}
		bridgeId := r.Header.Get(constants.HeaderBridgeIdentity)
		localService, _ := local.GetFromContext(r.Context())
		localService.SetBridgeIdentity(bridgeId)
		if bridgeId == "" {
			response.Write(r.Context(), response.Options{
				Code: http.StatusUnauthorized,
				Data: "Missing bridge id",
			})
			return
		}
		bridgeLabel := r.Header.Get(constants.HeaderBridgeLabel)
		localService.SetBridgeLabel(bridgeLabel)
		if bridgeLabel == "" {
			response.Write(r.Context(), response.Options{
				Code: http.StatusUnauthorized,
				Data: "Missing bridge label",
			})
			return
		}
		next.ServeHTTP(w, r)
	})
}

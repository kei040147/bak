package metric

import (
	"fmt"
	"net"
	"net/http"
	"runtime"
	"strings"
	"time"

	"github.com/bytedance/sonic"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/collectors"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"mini-app-ai-ws-gateway/common/configure"
	"mini-app-ai-ws-gateway/common/constants"
	"mini-app-ai-ws-gateway/utilities/cache"
	"mini-app-ai-ws-gateway/utilities/response_wrapper"
	"mini-app-ai-ws-gateway/utilities/tool"
	"mini-app-ai-ws-gateway/utilities/user_socket_hub"
)

var (
	cfg       = configure.GetConfig()
	startTime = time.Now()
)

type resCache struct {
	Header http.Header `json:"header"`
	Body   []byte      `json:"body"`
	Status int         `json:"status"`
}

func NewMetrics(method, path string, enable bool) func(next http.Handler) http.Handler {
	cacheService := cache.GetGlobal()
	reg := prometheus.NewRegistry()
	totalConnectionsMetric := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "total_connections",
		Help: "Number of current connections",
	})
	goroutineMetric := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "goroutine_count",
		Help: "Number of current process goroutines",
	})
	totalUsersMetric := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "total_users",
		Help: "Number of current users",
	})
	totalCpuCoreMetric := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "total_cpu_core",
		Help: "Number of cpu cores",
	})
	totalWaitingACKPacket := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "total_waiting_ack_packet",
		Help: "Number of waiting ACK packet",
	})
	socketDataCloneDuration := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "socket_hub_downtime",
		Help: "Processing time of GC map connections",
	})
	socketDataCloneAt := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "socket_hub_start_downtime_at",
		Help: "Start time of GC map connections",
	})
	serviceStartTime := prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "service_start_time_seconds",
		Help: "Start time of the service since unix epoch in seconds",
	})
	platforms := []int{
		constants.DevicePlatformUnknown, constants.DevicePlatformAndroid, constants.DevicePlatformIos,
		constants.DevicePlatformWindow, constants.DevicePlatformLinux, constants.DevicePlatformMac,
		constants.DevicePlatformWeb, constants.DevicePlatformIpad, constants.DevicePlatformTablet,
	}

	mapPlatformMetric := make(map[int]prometheus.Gauge)
	for _, platform := range platforms {
		metric := prometheus.NewGauge(prometheus.GaugeOpts{
			Name: fmt.Sprintf("total_connection_platform_%d", platform),
			Help: fmt.Sprintf("Number of current user online on platform %d", platform),
		})
		mapPlatformMetric[platform] = metric
		reg.MustRegister(metric)
	}
	reg.MustRegister(collectors.NewProcessCollector(collectors.ProcessCollectorOpts{}), collectors.NewGoCollector())
	reg.MustRegister(totalConnectionsMetric, totalUsersMetric, goroutineMetric, totalCpuCoreMetric,
		totalWaitingACKPacket, socketDataCloneDuration, socketDataCloneAt, serviceStartTime)
	return func(next http.Handler) http.Handler {
		fn := func(w http.ResponseWriter, r *http.Request) {
			allowedIP := false
			ip := net.ParseIP(tool.New().ReadUserIP(r))
			for _, subnetStr := range cfg.MetricMiddlewareAllowedSubnets {
				_, subnet, _ := net.ParseCIDR(subnetStr)
				if subnet != nil && subnet.Contains(ip) {
					allowedIP = true
					break
				}
			}
			if !(r.URL.Path == path && r.Method == method &&
				enable && allowedIP) {
				next.ServeHTTP(w, r)
				return
			}
			secretKey := r.Header.Get(constants.HeaderAuthorization)
			if secretKey != cfg.MetricSecretKey {
				w.WriteHeader(http.StatusUnauthorized)
				_, _ = w.Write([]byte("Secret key is wrong"))
				return
			}
			resData, _ := cacheService.Get("res", constants.CachePrefixPrometheusMetric)
			if len(resData) > 0 {
				var res resCache
				_ = sonic.Unmarshal(resData, &res)
				for k, v := range res.Header {
					w.Header().Add(k, strings.Join(v, ";"))
				}
				w.WriteHeader(http.StatusOK)
				_, _ = w.Write(res.Body)
				return
			}
			totalConnections := 0
			clients := user_socket_hub.GetHub().GetIdentityClients()
			totalUsers := len(clients)
			connections := make(map[int]int)
			for _, mapPlatform := range clients {
				for _, platform := range mapPlatform {
					totalConnections++
					connections[platform]++
				}
			}
			for _, platform := range platforms {
				mapPlatformMetric[platform].Set(float64(connections[platform]))
			}
			totalConnectionsMetric.Set(float64(totalConnections))
			totalUsersMetric.Set(float64(totalUsers))
			goroutineMetric.Set(float64(runtime.NumGoroutine()))
			totalCpuCoreMetric.Set(float64(runtime.NumCPU()))
			socketDataCloneDuration.Set(float64(user_socket_hub.GetHub().GetLastDowntime()))
			socketDataCloneAt.Set(float64(user_socket_hub.GetHub().GetLastStartDowntimeAt()))
			serviceStartTime.Set(float64(startTime.Unix()))
			rww := response_wrapper.New(w)
			promhttp.HandlerFor(reg, promhttp.HandlerOpts{Registry: reg}).ServeHTTP(rww, r)
			resData, _ = sonic.Marshal(resCache{
				Status: rww.StatusCode(),
				Header: rww.Header(),
				Body:   rww.Body().Bytes(),
			})
			_ = cacheService.Set("res", resData, cfg.MetricMiddlewareCacheDuration, constants.CachePrefixPrometheusMetric)
		}
		return http.HandlerFunc(fn)
	}
}

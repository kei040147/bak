package routers

import (
	"net/http"

	"github.com/go-chi/chi/v5"
	userCtrl "mini-app-ai-ws-gateway/api/controllers/user"
	"mini-app-ai-ws-gateway/api/middlewares/authenticate"
)

type User interface {
	V1() http.Handler
}

type user struct {
	controller userCtrl.Controller
}

func NewUser() User {
	return &user{controller: userCtrl.NewController()}
}

func (r *user) V1() http.Handler {
	router := chi.NewRouter()
	router.With(authenticate.WebsocketUserAuthenticate).Get("/connect", r.controller.ConnectWebSocket)
	return router
}

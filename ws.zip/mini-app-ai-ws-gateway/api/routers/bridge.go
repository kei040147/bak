package routers

import (
	"net/http"

	"github.com/go-chi/chi/v5"
	bridgeCtrl "mini-app-ai-ws-gateway/api/controllers/bridge"
	"mini-app-ai-ws-gateway/api/middlewares/authenticate"
)

type Bridge interface {
	V1() http.Handler
}

type bridge struct {
	controller bridgeCtrl.Controller
}

func NewBridge() Bridge {
	return &bridge{controller: bridgeCtrl.NewController()}
}

func (r *bridge) V1() http.Handler {
	router := chi.NewRouter()
	router.With(authenticate.WebsocketBridgeAuthenticate).Get("/connect", r.controller.ConnectWebSocket)
	return router
}

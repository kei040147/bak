package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/go-chi/chi/v5"
	"github.com/lesismal/llib/std/crypto/tls"
	"github.com/lesismal/nbio/nbhttp"
	_ "go.uber.org/automaxprocs"
	"mini-app-ai-ws-gateway/api/middlewares/metric"
	"mini-app-ai-ws-gateway/api/routers"
	"mini-app-ai-ws-gateway/common/configure"
	"mini-app-ai-ws-gateway/common/logging"
	"mini-app-ai-ws-gateway/common/logging/apm"
	"mini-app-ai-ws-gateway/common/request"
	"mini-app-ai-ws-gateway/common/response"
	"mini-app-ai-ws-gateway/database/mongo"
	"mini-app-ai-ws-gateway/utilities/bridge_socket_hub"
	"mini-app-ai-ws-gateway/utilities/cache"
	"mini-app-ai-ws-gateway/utilities/log_file"
	"mini-app-ai-ws-gateway/utilities/user_socket_hub"
)

var (
	cfg = configure.GetConfig()
)

func main() {
	logging.InitLogger()
	request.InitValidateEngine()
	mongo.InitDatabase()
	cache.New().InitGlobal()
	log_file.New(log_file.Option{
		LogFilePath:   cfg.LogFilePath,
		MaxBackupFile: cfg.LogFileMaxBackup,
		ServerDomain:  cfg.ServerDomain,
	}).Init()
	initSocketHub()
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)

	defaultRouteAPIV1 := "/api/mini-app-ai-ws/v1"
	r := chi.NewRouter()
	addMiddleware(r)
	r.Mount(fmt.Sprintf("%s/users", defaultRouteAPIV1), routers.NewUser().V1())
	r.Mount(fmt.Sprintf("%s/bridges", defaultRouteAPIV1), routers.NewBridge().V1())

	server := nbhttp.NewEngine(getHttpWsConfig(r))
	if err := server.Start(); err != nil {
		logging.GetLogger().Fatal().Err(err).Str("functionInline", "server.Start()").Msg("main")
	}
	<-sigChan
	logging.GetLogger().Info().Msg("Shutting down...")
	_ = server.Shutdown(context.Background())

	mongo.DisconnectDatabase()
}

func getHttpWsConfig(handler http.Handler) nbhttp.Config {
	serverConfig := nbhttp.Config{
		Name:                    "AI-WS-GATEWAY",
		Network:                 "tcp",
		KeepaliveTime:           cfg.ConnectKeepAliveTimeout,
		WriteTimeout:            cfg.ConnectWriteMessageTimeout,
		ReadBufferSize:          cfg.ConnectMessageBufferSize,
		ReleaseWebsocketPayload: true,
		IOMod:                   nbhttp.IOModNonBlocking,
		Handler:                 handler,
	}
	serverAddr := fmt.Sprintf("%s:%s", cfg.Host, cfg.Port)
	logging.GetLogger().Info().Bool("tls", cfg.TLSEnable).Msg("starting server at " + serverAddr)
	if cfg.TLSEnable {
		cert, err := tls.LoadX509KeyPair(cfg.TLSCertFile, cfg.TLSKeyFile)
		if err != nil {
			logging.GetLogger().Fatal().Err(err).Str("function", "getHttpWsConfig").Str("functionInline", "tls.LoadX509KeyPair").Msg("main")
		}
		serverConfig.AddrsTLS = []string{serverAddr}
		serverConfig.TLSConfig = &tls.Config{
			PreferServerCipherSuites: true,
			Certificates:             []tls.Certificate{cert},
			MinVersion:               tls.VersionTLS12,
			//CurvePreferences: []tls.CurveID{tls.CurveP521, tls.CurveP384, tls.CurveP256},
			CipherSuites: []uint16{
				tls.TLS_AES_256_GCM_SHA384,
				tls.TLS_CHACHA20_POLY1305_SHA256,
				tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
				tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
				tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
				tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
			},
		}
	} else {
		serverConfig.Addrs = []string{serverAddr}
	}
	return serverConfig
}

func addMiddleware(router chi.Router) {
	router.Use(logging.ChiLoggerMiddleware())
	router.Use(metric.NewMetrics(http.MethodGet, "/api/msg-ws/v1/metrics", cfg.MetricMiddlewareEnable))
	router.Use(response.WrapJson, response.PathNotFound)
	if cfg.TLSEnable {
		router.Use(func(next http.Handler) http.Handler {
			return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				next.ServeHTTP(w, r)
				w.Header().Add("Strict-Transport-Security", "max-age=63072000; includeSubDomains")
			})
		})
	}
	if cfg.ElasticAPMEnable {
		router.Use(apm.ChiApmMiddleware())
	}
}

func intUserSocketHub() {
	hub, err := user_socket_hub.NewHub(user_socket_hub.HubOption{
		Logger:           log_file.GetGlobal(),
		ReduceMemoryTime: cfg.SocketHubReduceMemoryTime,
	})
	if err != nil {
		logging.GetLogger().Fatal().Err(err).Str("function", "intUserSocketHub").Str("functionInline", "user_socket_hub.NewHub").Msg("main")
	}
	hub.InitGlobal()
}

func intBridgeSocketHub() {
	hub, err := bridge_socket_hub.NewHub(bridge_socket_hub.HubOption{
		Logger:           log_file.GetGlobal(),
		ReduceMemoryTime: cfg.SocketHubReduceMemoryTime,
	})
	if err != nil {
		logging.GetLogger().Fatal().Err(err).Str("function", "intBridgeSocketHub").Str("functionInline", "bridge_socket_hub.NewHub").Msg("main")
	}
	hub.InitGlobal()
}

func initSocketHub() {
	intBridgeSocketHub()
	intUserSocketHub()
}

# Sigpro Mini App AI Ws Gateway

| Environment                       | Default                   | Separator |
|-----------------------------------|---------------------------|-----------|
| HOST                              | 0.0.0.0                   |           |
| PORT                              | 8209                      |           |
| SERVER_DOMAIN                     | 0.0.0.0:8209              |           |
| TLS_CERT_FILE                     | ./certs/cert.pem          |           |
| TLS_KEY_FILE                      | ./certs/private.pem       |           |
| TOKEN_TYPE                        | Bearer                    |           |
| LOG_FILE_PATH                     | ./tmp                     |           |
| METRIC_SECRET_KEY                 | !change_me!               |           |
| SOCKET_HUB_REDUCE_MEMORY_TIME     | 01:00:00                  |           |
| MONGODB_AI_URI                    | mongodb://localhost:27017 |           |
| MONGODB_AI_NAME                   | db_ai                     |           |
| METRIC_MIDDLEWARE_ALLOWED_SUBNETS | 127.0.0.0/24              | ,         |
| CONNECT_KEEP_ALIVE_TIMEOUT        | 30s                       |           |
| CONNECT_WRITE_MESSAGE_TIMEOUT     | 10s                       |           |
| METRIC_MIDDLEWARE_CACHE_DURATION  | 50s                       |           |
| MONGODB_REQUEST_TIMEOUT           | 3m                        |           |
| CONNECT_MESSAGE_BUFFER_SIZE       | 65536                     |           |
| PAGINATION_MAX_ITEM               | 50                        |           |
| LOG_FILE_MAX_BACKUP               | 7                         |           |
| DEBUG                             | true                      |           |
| ELASTIC_APM_ENABLE                | false                     |           |
| TLS_ENABLE                        | false                     |           |
| METRIC_MIDDLEWARE_ENABLE          | true                      |           |
| MONGO_AUTO_INDEXING               | false                     |           |
| BRIDGE_SERVICE_SECRET_KEY         | !change_me!               |           |

### Elastic APM

| Environment                 | Example                |
|-----------------------------|------------------------|
| ELASTIC_APM_CAPTURE_BODY    | all                    |
| ELASTIC_APM_ENVIRONMENT     | development            |
| ELASTIC_APM_SERVICE_VERSION | 1.0.0                  |
| ELASTIC_APM_SERVICE_NAME    | mini-app-ai-ws-gateway |
| ELASTIC_APM_SECRET_TOKEN    | xxxxxx                 |
| ELASTIC_APM_SERVER_URL      | http://localhost:8200  |

---

## Develop

### Option 1: AIR

#### Install AIR to hot-reload

```shell
curl -sSfL https://raw.githubusercontent.com/cosmtrek/air/master/install.sh | sh -s
```

file config air: `.air.toml`

#### Add environment variable

update field full_bin in config

```
full_bin = "<envirnoment-variable> sh -c ./tmp/main"
```

example:

```
full_bin = "DEBUG=true sh -c ./tmp/main"
```

#### Run

```shell
air
```

### Option 2: Golang Run

```shell
go run main
```

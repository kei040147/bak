package constants

const (
	DevicePlatformUnknown = 0
	DevicePlatformAndroid = 1000
	DevicePlatformIos     = 2000
	DevicePlatformWindow  = 4000
	DevicePlatformLinux   = 5000
	DevicePlatformMac     = 6000
	DevicePlatformWeb     = 8000
	DevicePlatformIpad    = 10000
	DevicePlatformTablet  = 11000
)

const (
	OpCodeUnknown = -1
)

var MapPCPlatforms = map[int]struct{}{
	DevicePlatformWindow: {},
	DevicePlatformLinux:  {},
	DevicePlatformMac:    {},
}

var MapValidPlatforms = map[int]struct{}{
	DevicePlatformUnknown: {},
	DevicePlatformAndroid: {},
	DevicePlatformIos:     {},
	DevicePlatformWindow:  {},
	DevicePlatformLinux:   {},
	DevicePlatformMac:     {},
	DevicePlatformIpad:    {},
	DevicePlatformTablet:  {},
}

const (
	CachePrefixPCActive          = "#pc_active_"
	CachePrefixUserActiveDevices = "#user_active_devices"
	CachePrefixUserDeviceInfo    = "#user_devices_info"
	CachePrefixPrometheusMetric  = "!prometheus_metric_api_"
)

const (
	HeaderBridgeLabel    = "bridge_label"
	HeaderBridgeIdentity = "bridge_identity"
)

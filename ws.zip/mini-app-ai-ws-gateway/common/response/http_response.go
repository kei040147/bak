package response

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"reflect"

	"github.com/bytedance/sonic"
	"github.com/go-chi/chi/v5"
	"mini-app-ai-ws-gateway/common/local"
)

const (
	returnCodeMultiplier = 1000
)

type Options struct {
	Extra          map[string]interface{}
	Data           interface{}
	Code           int
	HttpStatusCode int
}

func (opt *Options) addDefaultValue() {
	if opt.Code < http.StatusContinue {
		opt.Code = http.StatusOK
	}
	if opt.Data == nil {
		opt.Data = map[string]interface{}{}
	}
	if opt.HttpStatusCode <= 0 {
		opt.HttpStatusCode = http.StatusOK
	}
}

type Error struct {
	Data           interface{} `json:"message"`
	Code           int         `json:"code"`
	HttpStatusCode int         `json:"-"`
}

func (e *Error) Error() string {
	return fmt.Sprintf("%v", e.Data)
}

type ErrorOptions struct {
	Data           interface{}
	HttpStatusCode int
}

type Service struct{}

func NewError(code int, opts ...ErrorOptions) *Error {
	e := &Error{Code: code, HttpStatusCode: http.StatusOK}
	if len(opts) > 0 {
		opt := opts[0]
		e.Data = opt.Data
		if opt.HttpStatusCode != 0 {
			e.HttpStatusCode = opt.HttpStatusCode
		}
	}
	if e.Data == nil {
		e.Data = http.StatusText(code)
	}
	return e
}

func Format(opt Options) ([]byte, int, int) {
	opt.addDefaultValue()
	respData := make(map[string]interface{})
	respData["return_code"] = opt.Code
	if http.StatusOK <= opt.Code && opt.Code < http.StatusMultipleChoices {
		respData["data"] = opt.Data
		if opt.Extra != nil {
			respData["extra"] = opt.Extra
		}
	} else {
		if opt.Data != nil {
			respData["error"] = opt.Data
		} else {
			respData["error"] = http.StatusText(opt.Code)
		}
	}
	respByte, _ := sonic.Marshal(respData)
	return respByte, opt.HttpStatusCode, opt.Code
}

func Write(ctx context.Context, opt Options) {
	localService, _ := local.GetFromContext(ctx)
	respByte, httpStatusCode, code := Format(opt)
	localService.SetResponseBody(respByte)
	localService.SetHTTPCode(httpStatusCode)
	localService.SetStatusCode(code)
}

func isConnectionHijacked(w http.ResponseWriter) bool {
	basicWriter := reflect.Indirect(reflect.ValueOf(w)).FieldByName("basicWriter")
	responseWriter := basicWriter.FieldByName("ResponseWriter").Elem()
	value := reflect.Indirect(responseWriter).FieldByName("hijacked").Bool()
	return value
}

func WriteError(ctx context.Context, err error) {
	localService, _ := local.GetFromContext(ctx)
	var (
		respByte       = make([]byte, 0)
		httpStatusCode = 0
		code           = 0
	)
	if e := new(Error); errors.As(err, &e) {
		respByte, httpStatusCode, code = Format(Options{
			Data:           e.Data,
			Code:           e.Code,
			HttpStatusCode: e.HttpStatusCode,
		})
	} else {
		respByte, httpStatusCode, code = Format(Options{
			Data:           err.Error(),
			Code:           http.StatusInternalServerError,
			HttpStatusCode: http.StatusInternalServerError,
		})
	}
	localService.SetResponseBody(respByte)
	localService.SetHTTPCode(httpStatusCode)
	localService.SetStatusCode(code)
}

func WrapJson(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ctx := local.InitToContext(r.Context())
		next.ServeHTTP(w, r.WithContext(ctx))
		if !isConnectionHijacked(w) {
			localService, _ := local.GetFromContext(ctx)
			statusCode := localService.GetHTTPCode()
			respData := localService.GetResponseBody()
			w.Header().Add("Content-Type", "application/json")
			w.WriteHeader(statusCode)
			_, _ = w.Write(respData)
		}
	})
}

func PathNotFound(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ctx := chi.RouteContext(r.Context())
		if !ctx.Routes.Match(chi.NewRouteContext(), r.Method, r.URL.Path) {
			WriteError(r.Context(), NewError(http.StatusNotFound, ErrorOptions{Data: "Path not found", HttpStatusCode: http.StatusNotFound}))
			return
		}
		next.ServeHTTP(w, r)
	})

}

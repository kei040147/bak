package configure

import (
	"time"

	"github.com/caarlos0/env/v11"
	"github.com/joho/godotenv"
	"github.com/rs/zerolog/log"
)

var config *Configuration

type Configuration struct {
	Host                           string        `env:"HOST" envDefault:"0.0.0.0"` // Server Host
	Port                           string        `env:"PORT" envDefault:"8209"`    // Server Port
	ServerDomain                   string        `env:"SERVER_DOMAIN,expand" envDefault:"$HOST:$PORT"`
	TLSCertFile                    string        `env:"TLS_CERT_FILE" envDefault:"./certs/cert.pem"`
	TLSKeyFile                     string        `env:"TLS_KEY_FILE" envDefault:"./certs/private.pem"`
	TokenType                      string        `env:"TOKEN_TYPE" envDefault:"Bearer"`
	LogFilePath                    string        `env:"LOG_FILE_PATH" envDefault:"./tmp"`
	MetricSecretKey                string        `env:"METRIC_SECRET_KEY" envDefault:"!change_me!"`
	BridgeServiceSecretKey         string        `env:"BRIDGE_SERVICE_SECRET_KEY" envDefault:"!change_me!"`
	SocketHubReduceMemoryTime      string        `env:"SOCKET_HUB_REDUCE_MEMORY_TIME" envDefault:"01:00:00"`
	MongoDBAiUri                   string        `env:"MONGODB_AI_URI" envDefault:"mongodb://localhost:27017"`
	MongoDBAiName                  string        `env:"MONGODB_AI_NAME" envDefault:"db_ai"`
	MetricMiddlewareAllowedSubnets []string      `env:"METRIC_MIDDLEWARE_ALLOWED_SUBNETS" envDefault:"127.0.0.0/24" envSeparator:","`
	ConnectKeepAliveTimeout        time.Duration `env:"CONNECT_KEEP_ALIVE_TIMEOUT" envDefault:"30s"`
	ConnectWriteMessageTimeout     time.Duration `env:"CONNECT_WRITE_MESSAGE_TIMEOUT" envDefault:"10s"`
	MetricMiddlewareCacheDuration  time.Duration `env:"METRIC_MIDDLEWARE_CACHE_DURATION" envDefault:"50s"`
	MongoDBRequestTimeout          time.Duration `env:"MONGODB_REQUEST_TIMEOUT" envDefault:"3m"`
	ConnectMessageBufferSize       int           `env:"CONNECT_MESSAGE_BUFFER_SIZE" envDefault:"65536"`
	PaginationMaxItem              int64         `env:"PAGINATION_MAX_ITEM" envDefault:"50"`
	LogFileMaxBackup               int           `env:"LOG_FILE_MAX_BACKUP" envDefault:"7"`
	Debug                          bool          `env:"DEBUG" envDefault:"true"` // Enable Debug mode
	ElasticAPMEnable               bool          `env:"ELASTIC_APM_ENABLE" envDefault:"false"`
	TLSEnable                      bool          `env:"TLS_ENABLE" envDefault:"false"`
	MetricMiddlewareEnable         bool          `env:"METRIC_MIDDLEWARE_ENABLE" envDefault:"true"`
	MongoAutoIndexing              bool          `env:"MONGO_AUTO_INDEXING" envDefault:"false"`
}

func GetConfig() Configuration {
	if config == nil {
		_ = godotenv.Load()
		config = &Configuration{}
		if err := env.Parse(config); err != nil {
			log.Fatal().Err(err).Msg("Get Config Error")
		}
	}
	return *config
}

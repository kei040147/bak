package request

import (
	"mini-app-ai-ws-gateway/common/configure"
	"mini-app-ai-ws-gateway/common/logging"
)

var (
	logger = logging.GetLogger()
	cfg    = configure.GetConfig()
)

package request

import (
	"github.com/go-playground/validator/v10"
)

var validateEngine *validator.Validate

type ValidateFunction struct {
	Function validator.Func
	Tag      string
}

func InitValidateEngine() *validator.Validate {
	validateEngine = validator.New()
	RegisterValidate()
	return validateEngine
}

func GetValidateEngine() *validator.Validate {
	return validateEngine
}

func RegisterValidate(functions ...ValidateFunction) {
	for _, function := range functions {
		if err := validateEngine.RegisterValidation(function.Tag, function.Function); err != nil {
			logger.Fatal().Err(err).Msg("register tag validate error")
		}
	}
}

func ParseValidateError(rawErr error) map[string]interface{} {
	result := map[string]interface{}{}
	for _, err := range rawErr.(validator.ValidationErrors) {
		result[err.Field()] = err.ActualTag()
	}
	return result
}

package logging

import (
	"io"
	"net/http"
	"os"
	"reflect"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/go-chi/chi/v5/middleware"
	"github.com/rs/zerolog"
	"mini-app-ai-ws-gateway/common/configure"
	"mini-app-ai-ws-gateway/common/constants"
)

var logger *zerolog.Logger

func InitLogger() {
	logger = createLogger()
	if configure.GetConfig().Debug {
		zerolog.SetGlobalLevel(zerolog.TraceLevel)
	} else {
		zerolog.SetGlobalLevel(zerolog.InfoLevel)
	}
}

func GetLogger() *zerolog.Logger {
	if logger == nil {
		InitLogger()
	}
	return logger
}

func createLogger() *zerolog.Logger {
	log := zerolog.New(getLogWriter()).With().Timestamp().Logger()
	return &log
}

func getLogWriter() zerolog.ConsoleWriter {
	return zerolog.ConsoleWriter{Out: os.Stdout, TimeFormat: time.RFC3339}
}

// Logger variables
const (
	TagPid               = "pid"
	TagTime              = "time"
	TagReferer           = "referer"
	TagProtocol          = "protocol"
	TagID                = "id"
	TagIP                = "ip"
	TagIPs               = "ips"
	TagHost              = "host"
	TagMethod            = "method"
	TagPath              = "path"
	TagURL               = "url"
	TagUA                = "ua"
	TagLatency           = "latency"
	TagStatus            = "status"
	TagResBody           = "resBody"
	TagQueryStringParams = "queryParams"
	TagBody              = "body"
	TagBytesSent         = "bytesSent"
	TagBytesReceived     = "bytesReceived"
	TagRoute             = "route"
	TagError             = "error"
	TagHeader            = "header:"
	TagLocals            = "locals:"
	TagQuery             = "query:"
	TagForm              = "form:"
	TagCookie            = "cookie:"
)

const timeIntervalDefault = 500

type LoggerMiddlewareConfig struct {
	logger           zerolog.Logger
	Next             func(next http.Handler) http.Handler
	timeZoneLocation *time.Location
	TimeFormat       string
	TimeZone         string
	Format           []string
	TimeInterval     time.Duration
	PrettyLatency    bool
	enableLatency    bool
}

// defaultConfig is the default config
var defaultLoggerMiddlewareConfig = LoggerMiddlewareConfig{
	Next:         nil,
	Format:       []string{TagTime, TagStatus, TagLatency, TagMethod, TagPath},
	TimeFormat:   time.RFC3339,
	TimeZone:     "Local",
	TimeInterval: timeIntervalDefault * time.Millisecond,
}

func (cfg *LoggerMiddlewareConfig) setTimezoneLocation() {
	tz, err := time.LoadLocation(cfg.TimeZone)
	if err != nil || tz == nil {
		cfg.timeZoneLocation = time.Local
	} else {
		cfg.timeZoneLocation = tz
	}
}

func (cfg *LoggerMiddlewareConfig) checkEnableLatency() {
	for _, tag := range cfg.Format {
		if tag == TagLatency {
			cfg.enableLatency = true
			break
		}
	}
}

func setLoggerMiddlewareConfig(config []LoggerMiddlewareConfig) LoggerMiddlewareConfig {
	// Return default config if nothing provided
	if len(config) < 1 {
		cfg := defaultLoggerMiddlewareConfig
		cfg.logger = *logger
		return cfg
	}

	// Override default config
	cfg := config[0]
	if cfg.Next == nil {
		cfg.Next = defaultLoggerMiddlewareConfig.Next
	}
	if cfg.Format == nil {
		cfg.Format = defaultLoggerMiddlewareConfig.Format
	}
	if cfg.TimeZone == "" {
		cfg.TimeZone = defaultLoggerMiddlewareConfig.TimeZone
	}
	if cfg.TimeFormat == "" {
		cfg.TimeFormat = defaultLoggerMiddlewareConfig.TimeFormat
	}
	if int(cfg.TimeInterval) <= 0 {
		cfg.TimeInterval = defaultLoggerMiddlewareConfig.TimeInterval
	}
	cfg.logger = *logger
	return cfg
}

func isConnectionHijacked(w http.ResponseWriter) bool {
	return reflect.Indirect(reflect.ValueOf(w)).FieldByName("hijacked").Bool()
}

// nolint: gocyclo
func ChiLoggerMiddleware(config ...LoggerMiddlewareConfig) func(next http.Handler) http.Handler {
	cfg := setLoggerMiddlewareConfig(config)
	cfg.setTimezoneLocation()
	cfg.checkEnableLatency()

	// Create correct time format
	var timestamp atomic.Value
	timestamp.Store(time.Now().In(cfg.timeZoneLocation).Format(cfg.TimeFormat))

	// Update date/time in a separate go routine
	for _, tag := range cfg.Format {
		if tag == TagTime {
			go func() {
				for {
					time.Sleep(cfg.TimeInterval)
					timestamp.Store(time.Now().In(cfg.timeZoneLocation).Format(cfg.TimeFormat))
				}
			}()
			break
		}
	}
	// Set PID once
	pid := strconv.Itoa(os.Getpid())
	return func(next http.Handler) http.Handler {
		fn := func(w http.ResponseWriter, r *http.Request) {
			if cfg.Next != nil {
				handler := cfg.Next(next)
				if handler != nil {
					handler.ServeHTTP(w, r)
					return
				}
			}
			var start, stop time.Time
			if cfg.enableLatency {
				start = time.Now()
			}

			ww := middleware.NewWrapResponseWriter(w, r.ProtoMajor)
			defer func() {
				if cfg.enableLatency {
					stop = time.Now()
				}
				status := ww.Status()
				var event *zerolog.Event
				switch {
				case status >= http.StatusContinue && status < http.StatusBadRequest:
					event = cfg.logger.Info()
				case status >= http.StatusBadRequest && status < http.StatusInternalServerError:
					event = cfg.logger.Warn()
				case status >= http.StatusInternalServerError:
					event = cfg.logger.Error()
				default:
					event = cfg.logger.Debug()
					if isConnectionHijacked(ww.Unwrap()) {
						event = cfg.logger.Info()
						status = http.StatusSwitchingProtocols
					}
				}

				for _, tag := range cfg.Format {
					switch tag {
					case TagTime:
						event = event.Str(TagTime, timestamp.Load().(string))
					case TagReferer:
						event = event.Str(TagReferer, r.Header.Get(TagReferer))
					case TagProtocol:
						event = event.Str(TagProtocol, r.Proto)
					case TagPid:
						event = event.Str(TagPid, pid)
					case TagID:
						event = event.Str(TagID, r.Header.Get(constants.HeaderXRequestID))
					case TagIP:
						event = event.Str(TagIP, r.RemoteAddr)
					case TagIPs:
						event = event.Str(TagIPs, r.Header.Get(constants.HeaderXForwardedFor))
					case TagHost:
						event = event.Str(TagHost, r.Host)
					case TagPath:
						event = event.Str(TagPath, r.URL.Path)
					case TagURL:
						event = event.Str(TagURL, r.URL.String())
					case TagUA:
						event = event.Str(TagUA, r.UserAgent())
					case TagLatency:
						if cfg.PrettyLatency {
							event = event.Str(TagLatency, stop.Sub(start).String())
						} else {
							event = event.Dur(TagLatency, stop.Sub(start))
						}
					case TagBody:
						b, _ := io.ReadAll(r.Body)
						event = event.Bytes(TagBody, b)
					case TagBytesReceived:
						event = event.Int(TagBytesReceived, int(r.ContentLength))
					case TagBytesSent:
						event = event.Int(TagBytesSent, ww.BytesWritten())
					case TagRoute:
						event = event.Str(TagRoute, r.RequestURI)
					case TagStatus:
						event = event.Int(TagStatus, status)
					case TagQueryStringParams:
						event = event.Str(TagQueryStringParams, r.URL.RawQuery)
					case TagMethod:
						event = event.Str(TagMethod, r.Method)
					}
				}
				event.Msg(http.StatusText(status))
			}()
			next.ServeHTTP(ww, r)
		}
		return http.HandlerFunc(fn)
	}
}

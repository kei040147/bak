package local

import (
	"context"
	"errors"
)

type User interface {
	GetUsername() string
}

type UUIDInfo interface {
	GetPlatform() int
}

type Service interface {
	GetStatusCode() int
	GetHTTPCode() int
	GetAPMResponseBody() []byte
	GetResponseBody() []byte
	GetRequestBody() []byte
	GetUsername() string
	GetDevicePlatform() int
	GetUserOnlyFields() []string
	GetUser() User
	GetExtraBody() string
	SetUsername(value string)
	SetStatusCode(value int)
	SetHTTPCode(value int)
	SetAPMResponseBody(value []byte)
	SetResponseBody(value []byte)
	SetRequestBody(value []byte)
	SetDevicePlatform(value int)
	SetUser(value User)
	SetUserOnlyFields(fields ...string)
	SetExtraBody(value string)
	SetBridgeLabel(value string)
	GetBridgeLabel() string
	SetBridgeIdentity(value string)
	GetBridgeIdentity() string
}

const (
	keyAPMResponseBody = "!apmResponseBody"
	keyLocalStorage    = "!localStorage"
	KeyHTTPCode        = "httpCode"
	KeyStatusCode      = "statusCode"
	KeyRequestBody     = "requestBody"
	KeyResponseBody    = "responseBody"
	KeyUsername        = "username"
	KeyUser            = "user"
	KeyDeviceID        = "deviceID"
	KeyDevicePlatform  = "devicePlatform"
	KeyAPICode         = "apiCode"
	KeyUserOnlyFields  = "userOnlyFields"
	KeyDeviceInfo      = "deviceInfo"
	KeyAppVersion      = "appVersion"
	KeyAppCode         = "appCode"
	KeyOsVersion       = "osVersion"
	KeyExtraBody       = "extraBody"
	KeyBridgeLabel     = "bridgeLabel"
	KeyBridgeIdentity  = "bridgeIdentity"
)

const (
	unknownPlatform = 3999
)

var (
	defaultUserOnlyFields    = []string{"sip_id", "_id", "active", "new_rule", "public_key", "deleted_at"}
	mapDefaultUserOnlyFields = map[string]struct{}{
		"sip_id":     {},
		"_id":        {},
		"active":     {},
		"new_rule":   {},
		"public_key": {},
		"deleted_at": {},
	}
)

type service struct {
	db map[string]interface{}
}

func New() Service {
	return &service{db: map[string]interface{}{}}
}

func InitToContext(ctx context.Context) context.Context {
	return context.WithValue(ctx, keyLocalStorage, New())
}

func GetFromContext(ctx context.Context) (Service, error) {
	if item, ok := ctx.Value(keyLocalStorage).(Service); ok {
		return item, nil
	}
	return nil, errors.New("local: unable to get service")
}

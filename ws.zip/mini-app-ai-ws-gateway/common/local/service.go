package local

import (
	"net/http"
)

func (s service) SetStatusCode(value int) {
	s.db[KeyStatusCode] = value
}

func (s service) GetStatusCode() int {
	if value, ok := s.db[KeyStatusCode].(int); ok {
		return value
	}
	return http.StatusInternalServerError
}

func (s service) SetHTTPCode(value int) {
	s.db[KeyHTTPCode] = value
}

func (s service) GetHTTPCode() int {
	if value, ok := s.db[KeyHTTPCode].(int); ok {
		return value
	}
	return http.StatusInternalServerError
}

func (s service) SetAPMResponseBody(value []byte) {
	s.db[keyAPMResponseBody] = value
}

func (s service) GetAPMResponseBody() []byte {
	if value, ok := s.db[keyAPMResponseBody].([]byte); ok {
		return value
	}
	return []byte("{}")
}

func (s service) SetResponseBody(value []byte) {
	s.db[KeyResponseBody] = value
}

func (s service) GetResponseBody() []byte {
	if value, ok := s.db[KeyResponseBody].([]byte); ok {
		return value
	}
	return []byte("{}")
}

func (s service) SetRequestBody(value []byte) {
	s.db[KeyRequestBody] = value
}

func (s service) GetRequestBody() []byte {
	if value, ok := s.db[KeyRequestBody].([]byte); ok {
		return value
	}
	return []byte("{}")
}

func (s service) SetUsername(value string) {
	s.db[KeyUsername] = value
}

func (s service) GetUsername() string {
	if value, ok := s.db[KeyUsername].(string); ok {
		return value
	}
	return ""
}

func (s service) SetDevicePlatform(value int) {
	s.db[KeyDevicePlatform] = value
}

func (s service) GetDevicePlatform() int {
	if value, ok := s.db[KeyDevicePlatform].(int); ok {
		return value
	}
	return unknownPlatform
}

func (s service) SetUserOnlyFields(fields ...string) {
	onlyFields := defaultUserOnlyFields
	for _, field := range fields {
		if _, ok := mapDefaultUserOnlyFields[field]; !ok {
			onlyFields = append(onlyFields, field)
		}
	}
	s.db[KeyUserOnlyFields] = onlyFields
}

func (s service) GetUserOnlyFields() []string {
	if fields, ok := s.db[KeyUserOnlyFields].([]string); ok {
		return fields
	}
	return defaultUserOnlyFields
}

func (s service) SetUser(value User) {
	s.db[KeyUser] = value
}

func (s service) GetUser() User {
	if value, ok := s.db[KeyUser].(User); ok {
		return value
	}
	return nil
}

func (s service) GetExtraBody() string {
	if value, ok := s.db[KeyExtraBody].(string); ok {
		return value
	}
	return ""
}

func (s service) SetExtraBody(value string) {
	s.db[KeyExtraBody] = value
}

func (s service) SetBridgeLabel(value string) {
	s.db[KeyBridgeLabel] = value
}

func (s service) GetBridgeLabel() string {
	if value, ok := s.db[KeyBridgeLabel].(string); ok {
		return value
	}
	return ""
}

func (s service) SetBridgeIdentity(value string) {
	s.db[KeyBridgeIdentity] = value
}

func (s service) GetBridgeIdentity() string {
	if value, ok := s.db[KeyBridgeIdentity].(string); ok {
		return value
	}
	return ""
}

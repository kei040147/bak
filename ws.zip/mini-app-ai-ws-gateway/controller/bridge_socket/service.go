package bridge_socket

import (
	"errors"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/lesismal/nbio/nbhttp/websocket"
	"mini-app-ai-ws-gateway/common/constants"
	"mini-app-ai-ws-gateway/utilities/bridge_socket_hub"
	"mini-app-ai-ws-gateway/utilities/log_file"
)

func (h *handler) HandlePacket(conn *websocket.Conn, opCode websocket.MessageType, rawPacket []byte) error {
	client, err := bridge_socket_hub.GetHub().GetClientByConn(conn)
	log_file.GetGlobal().GetDomainEventLogger().Err(err).Str("function", "HandlePacket").Str("type", "receive").
		Interface("opCode", opCode).Interface("user_info", client.Info).Bytes("reqBody", rawPacket).
		Int("packet_length", len(rawPacket)).Str("socket_id", client.Id).Msg("bridge_socket_hub")
	if err != nil {
		return err
	}
	return nil
}

func (h *handler) ConnectionHandler(conn *websocket.Conn, disconnected bool, err error) {
	socketHub := bridge_socket_hub.GetHub()
	sender, _ := socketHub.GetClientByConn(conn)
	packetId := fmt.Sprintf("%s-%v", uuid.NewString(), time.Now().UnixNano())
	var connectDuration int64 = -1
	if disconnected {
		connectDuration = time.Since(sender.GetConnectedAt()).Milliseconds()
		if connectDuration < 0 {
			connectDuration = 0
			connErr := "connect duration invalid"
			if err != nil {
				connErr = fmt.Sprintf("%s-%s", err.Error(), connErr)
			}
			err = errors.New(connErr)
		}
	}
	log_file.GetGlobal().GetDomainEventLogger().Err(err).Str("function", "ConnectionHandler").Str("type", "connect").
		Str("packet_id", packetId).Interface("opCode", constants.OpCodeUnknown).Interface("user_info", sender.Info).
		Str("reqBody", fmt.Sprintf("{\"disconnected\":%v}", disconnected)).Int64("connect_duration", connectDuration).
		Str("socket_id", sender.Id).Msg("bridge_socket_hub")

	if !disconnected {
		return
	}
	_ = socketHub.Unregister(sender)
}

func (h *handler) HandlePing(conn *websocket.Conn, rawPacket string) error {
	client, err := bridge_socket_hub.GetHub().GetClientByConn(conn)
	log_file.GetGlobal().GetDomainEventLogger().Err(err).Str("function", "Run").Str("type", "receive").
		Interface("opCode", websocket.PingMessage).Str("packet_id", "").
		Interface("user_info", client.Info).Str("reqBody", rawPacket).Str("socket_id", client.Id).Msg("bridge_socket_hub")
	if err != nil {
		return err
	}
	err = conn.WriteMessage(websocket.PongMessage, []byte(rawPacket))
	return err
}

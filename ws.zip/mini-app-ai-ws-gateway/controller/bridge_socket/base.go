package bridge_socket

import (
	"github.com/lesismal/nbio/nbhttp/websocket"
)

type handler struct {
}

type Handler interface {
	HandlePacket(conn *websocket.Conn, opCode websocket.MessageType, rawPacket []byte) error
	ConnectionHandler(conn *websocket.Conn, disconnected bool, err error)
	HandlePing(conn *websocket.Conn, rawPacket string) error
}

func New() Handler {
	return &handler{}
}

package mongo

import (
	"context"

	"go.elastic.co/apm/module/apmmongo/v2"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"mini-app-ai-ws-gateway/common/configure"
	"mini-app-ai-ws-gateway/common/logging"
)

var (
	aiDBClient *mongo.Client
	logger     = logging.GetLogger()
	cfg        = configure.GetConfig()
	utils      = NewUtilityService()
)

func InitDatabase() {
	aiDBClient = initClientConnection(cfg.MongoDBAiUri, cfg.ElasticAPMEnable)
	autoIndexing()
}

func autoIndexing() {
	if cfg.MongoAutoIndexing {
	}
}

func DisconnectDatabase() {
	_ = aiDBClient.Disconnect(context.Background())
}

func initClientConnection(mongoURI string, enableAPM bool) *mongo.Client {
	opts := options.Client()
	opts.ApplyURI(mongoURI)
	if enableAPM {
		opts.SetMonitor(apmmongo.CommandMonitor())
	}
	ctx, cancel := utils.GetContextTimeout(context.Background())
	defer cancel()
	client, err := mongo.Connect(ctx, opts)
	if err != nil {
		logger.Fatal().Err(err).Str("function", "initClientConnection").Str("functionInline", "mongo.Connect").Msg("database")
	}
	ctxPing, cancelPing := utils.GetContextTimeout(context.Background())
	defer cancelPing()
	if err = client.Ping(ctxPing, nil); err != nil {
		logger.Fatal().Err(err).Str("function", "initClientConnection").Str("functionInline", "client.Ping").Msg("database")
	}
	return client
}

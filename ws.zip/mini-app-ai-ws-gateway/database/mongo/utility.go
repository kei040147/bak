package mongo

import (
	"context"

	"go.mongodb.org/mongo-driver/mongo"
	"mini-app-ai-ws-gateway/database/mongo/models"
)

type UtilityService interface {
	GetContextTimeout(ctx context.Context) (context.Context, context.CancelFunc)
	GetWsSession() (coll *mongo.Collection)
	GetUserCollection() (coll *mongo.Collection)
}

type utilityService struct{}

func NewUtilityService() UtilityService {
	service := utilityService{}
	return &service
}

func (s *utilityService) GetContextTimeout(ctx context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(ctx, cfg.MongoDBRequestTimeout)
}

func (s *utilityService) getAiDB() (db *mongo.Database) {
	return aiDBClient.Database(cfg.MongoDBAiName)
}

func (s *utilityService) GetWsSession() (coll *mongo.Collection) {
	return s.getAiDB().Collection(new(models.WsSession).CollectionName())
}

func (s *utilityService) GetUserCollection() (coll *mongo.Collection) {
	return s.getAiDB().Collection(new(models.User).CollectionName())
}

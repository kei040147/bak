package queries

import (
	"context"
	"errors"
	"net/http"

	"go.mongodb.org/mongo-driver/bson"
	mongoDriver "go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"mini-app-ai-ws-gateway/common/response"
	"mini-app-ai-ws-gateway/database/mongo"
	"mini-app-ai-ws-gateway/database/mongo/models"
)

type WsSessionQuery interface {
	GetByUsernameSessionKeyAndPlatform(username, sessionKey string, platform int, opts ...OptionsQuery) (wsSession *models.WsSession, err error)
	DeleteBySessionKey(sessionKey string) error
}

type wsSessionQuery struct {
	collection *mongoDriver.Collection
	context    context.Context
}

func NewWsSessionQuery(ctx context.Context) WsSessionQuery {
	return &wsSessionQuery{
		context:    ctx,
		collection: mongo.NewUtilityService().GetWsSession(),
	}
}

func (q *wsSessionQuery) GetByUsernameSessionKeyAndPlatform(username, sessionKey string, platform int, opts ...OptionsQuery) (*models.WsSession, error) {
	opt := NewOptions()
	if len(opts) > 0 {
		opt = opts[0]
	}
	var data models.WsSession
	optFind := &options.FindOneOptions{Projection: opt.QueryOnlyField()}
	ctx, cancel := timeoutFunc(q.context)
	defer cancel()
	if err := q.collection.FindOne(ctx, bson.M{
		"username":    username,
		"platform":    platform,
		"session_key": sessionKey,
	}, optFind).Decode(&data); err != nil {
		if errors.Is(err, mongoDriver.ErrNoDocuments) {
			return nil, response.NewError(http.StatusNotFound, response.ErrorOptions{Data: "Session not found"})
		}
		logger.Error().Err(err).Str("function", "GetByUsernameSessionKeyAndPlatform").Str("functionInline", "q.collection.FindOne").Msg("wsSessionQuery")
		return nil, response.NewError(http.StatusInternalServerError)
	}
	return &data, nil
}

func (q *wsSessionQuery) DeleteBySessionKey(sessionKey string) error {
	ctx, cancel := timeoutFunc(q.context)
	defer cancel()
	if _, err := q.collection.DeleteOne(ctx, bson.M{"session_key": sessionKey}); err != nil {
		logger.Error().Err(err).Str("function", "DeleteBySessionKey").Str("functionInline", "q.collection.DeleteOne").Msg("wsSessionQuery")
		return response.NewError(http.StatusInternalServerError)
	}
	return nil
}

package queries

import (
	"go.mongodb.org/mongo-driver/bson"
	"mini-app-ai-ws-gateway/common/logging"
	"mini-app-ai-ws-gateway/common/request"
	"mini-app-ai-ws-gateway/database/mongo"
)

var (
	logger      = logging.GetLogger()
	timeoutFunc = mongo.NewUtilityService().GetContextTimeout
)

const (
	SortTypeDesc = -1
	SortTypeAsc  = 1
)

type OptionsQuery interface {
	SetOnlyFields(fieldNames ...string)
	SetPagination(pagination *request.Pagination)
	QueryOnlyField() interface{}
	QueryPaginationLimit() *int64
	QueryPaginationPage() *int64
	QueryPaginationSkip() *int64
	QuerySort() bson.D
	ResetSort()
	AddSortKey(map[string]int)
}

type optionsQuery struct {
	pagination *request.Pagination
	sort       bson.D
	onlyFields []string
}

func NewOptions() OptionsQuery {
	return &optionsQuery{}
}

func (o *optionsQuery) SetOnlyFields(fieldNames ...string) {
	o.onlyFields = fieldNames
}

func (o *optionsQuery) SetPagination(pagination *request.Pagination) {
	o.pagination = pagination
}

func (o *optionsQuery) QueryOnlyField() interface{} {
	if len(o.onlyFields) < 1 {
		return nil
	}
	result := make(bson.M)
	for _, fieldName := range o.onlyFields {
		result[fieldName] = 1
	}
	return result
}

func (o *optionsQuery) QueryPaginationLimit() *int64 {
	if o.pagination == nil {
		return nil
	}
	return &o.pagination.Limit
}

func (o *optionsQuery) QueryPaginationPage() *int64 {
	if o.pagination == nil {
		return nil
	}
	return &o.pagination.Page
}

func (o *optionsQuery) QueryPaginationSkip() *int64 {
	if o.pagination == nil {
		return nil
	}
	return &o.pagination.Skip
}

func (o *optionsQuery) AddSortKey(sorts map[string]int) {
	for sortBy, sortType := range sorts {
		if sortType != SortTypeAsc && sortType != SortTypeDesc {
			sortType = SortTypeDesc
		}
		o.sort = append(o.sort, bson.E{Key: sortBy, Value: sortType})
	}
}

func (o *optionsQuery) ResetSort() {
	o.sort = make(bson.D, 0)
}

func (o *optionsQuery) QuerySort() bson.D {
	return o.sort
}

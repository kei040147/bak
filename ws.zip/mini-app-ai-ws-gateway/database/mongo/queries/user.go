package queries

import (
	"context"
	"errors"
	"net/http"

	"go.mongodb.org/mongo-driver/bson"
	mongoDriver "go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"mini-app-ai-ws-gateway/common/response"
	"mini-app-ai-ws-gateway/database/mongo"
	"mini-app-ai-ws-gateway/database/mongo/models"
)

type UserQuery interface {
	GetByUsername(username string, opts ...OptionsQuery) (user *models.User, err error)
}

type userQuery struct {
	collection *mongoDriver.Collection
	context    context.Context
}

func NewUser(ctx context.Context) UserQuery {
	return &userQuery{
		collection: mongo.NewUtilityService().GetUserCollection(),
		context:    ctx,
	}
}

func (q *userQuery) GetByUsername(username string, opts ...OptionsQuery) (*models.User, error) {
	opt := NewOptions()
	if len(opts) > 0 {
		opt = opts[0]
	}
	var data models.User
	optFind := &options.FindOneOptions{Projection: opt.QueryOnlyField()}
	ctx, cancel := timeoutFunc(q.context)
	defer cancel()
	if err := q.collection.FindOne(ctx, bson.M{"username": username}, optFind).Decode(&data); err != nil {
		if errors.Is(err, mongoDriver.ErrNoDocuments) {
			return nil, response.NewError(http.StatusNotFound, response.ErrorOptions{Data: "User not found"})
		}
		logger.Error().Err(err).Str("function", "GetByUsername").Str("functionInline", "q.collection.FindOne").Msg("userQuery")
		return nil, response.NewError(http.StatusInternalServerError)
	}
	return &data, nil
}

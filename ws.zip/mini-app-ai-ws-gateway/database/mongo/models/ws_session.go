package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type WsSession struct {
	CreatedAt  time.Time          `bson:"created_at"`
	UpdatedAt  time.Time          `bson:"updated_at"`
	ExpiredAt  time.Time          `bson:"expired_at"`
	Username   string             `bson:"username"`
	SessionKey string             `bson:"session_key"`
	Platform   int                `bson:"platform"`
	Id         primitive.ObjectID `bson:"_id"`
}

func (m *WsSession) CollectionName() string {
	return "ws_sessions"
}

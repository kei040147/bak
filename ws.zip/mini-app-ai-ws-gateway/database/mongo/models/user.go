package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type User struct {
	CreatedAt time.Time          `bson:"created_at"`
	UpdatedAt time.Time          `bson:"updated_at"`
	Username  string             `bson:"username"`
	Alias     string             `bson:"alias"`
	AvatarUrl string             `bson:"avatar_url"`
	Id        primitive.ObjectID `bson:"_id,omitempty"`
}

func (m *User) CollectionName() string {
	return "users"
}

func (m *User) GetUsername() string {
	return m.Username
}

package cache

import (
	"time"

	"github.com/gofiber/storage/memory/v2"
)

var global Service

type Service interface {
	InitGlobal()
	Get(key string, prefix ...string) ([]byte, error)
	Set(key string, val []byte, exp time.Duration, prefix ...string) error
	Delete(key string, prefix ...string) error
}

type service struct {
	store *memory.Storage
}

func New() Service {
	return &service{
		store: memory.New(),
	}
}

func GetGlobal() Service {
	return global
}

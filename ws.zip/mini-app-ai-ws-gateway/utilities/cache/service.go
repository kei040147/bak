package cache

import (
	"time"
)

func (s *service) InitGlobal() {
	global = s
}

func (s *service) Get(key string, prefix ...string) ([]byte, error) {
	if len(prefix) > 0 {
		key = prefix[0] + key
	}
	return s.store.Get(key)
}

func (s *service) Set(key string, val []byte, exp time.Duration, prefix ...string) error {
	if len(prefix) > 0 {
		key = prefix[0] + key
	}
	return s.store.Set(key, val, exp)
}

func (s *service) Delete(key string, prefix ...string) error {
	if len(prefix) > 0 {
		key = prefix[0] + key
	}
	return s.store.Delete(key)
}

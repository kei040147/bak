package user_socket_hub

const (
	devicePlatformAndroid = 1000
	devicePlatformIos     = 2000
	devicePlatformWindow  = 4000
	devicePlatformLinux   = 5000
	devicePlatformMac     = 6000
	devicePlatformIpad    = 10000
	devicePlatformTablet  = 11000
)

const closeCodePolicyViolation = 1008

package user_socket_hub

import "errors"

var (
	ErrNoConnection      = errors.New("no connection")
	ErrMinVersionAppCode = errors.New("min version app code")
	ErrUserNotFound      = errors.New("user not found")
)

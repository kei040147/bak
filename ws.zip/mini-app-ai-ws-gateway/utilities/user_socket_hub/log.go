package user_socket_hub

import (
	"github.com/rs/zerolog"
)

type LogService interface {
	Init()
	GetLogger() *zerolog.Logger
	GetDomain() string
	GetDomainEventLogger() *zerolog.Event
}
type logService struct {
	logger *zerolog.Logger
}

func NewLogService() LogService {
	return &logService{logger: &zerolog.Logger{}}
}

func (l *logService) Init() {}

func (l *logService) GetLogger() *zerolog.Logger {
	return l.logger
}

func (l *logService) GetDomain() string {
	return ""
}

func (l *logService) GetDomainEventLogger() *zerolog.Event {
	return l.logger.Info().Str("domain", l.GetDomain())
}

package user_socket_hub

import (
	"time"

	"github.com/lesismal/nbio/nbhttp/websocket"
)

func (h *hub) InitGlobal() {
	globalHub = h
}

func (h *hub) Register(info ClientInfo, conn *websocket.Conn) error {
	c := NewClient(info, conn)
	h.lock.Lock()
	defer h.lock.Unlock()
	h.connections[c.Id] = c
	const maxPlatformChecking = 3
	platformNeedChecking := make([]int, 0, maxPlatformChecking)
	platformNeedChecking = append(platformNeedChecking, c.Info.Platform)
	switch c.Info.Platform {
	case devicePlatformAndroid:
		platformNeedChecking = append(platformNeedChecking, devicePlatformIos)
	case devicePlatformIos:
		platformNeedChecking = append(platformNeedChecking, devicePlatformAndroid)
	case devicePlatformIpad:
		platformNeedChecking = append(platformNeedChecking, devicePlatformTablet)
	case devicePlatformTablet:
		platformNeedChecking = append(platformNeedChecking, devicePlatformIpad)
	case devicePlatformWindow:
		platformNeedChecking = append(platformNeedChecking, devicePlatformLinux, devicePlatformMac)
	case devicePlatformMac:
		platformNeedChecking = append(platformNeedChecking, devicePlatformWindow, devicePlatformLinux)
	case devicePlatformLinux:
		platformNeedChecking = append(platformNeedChecking, devicePlatformWindow, devicePlatformMac)
	}
	for _, item := range platformNeedChecking {
		if connId, ok := h.identityClients[c.Info.Username][item]; ok {
			_ = h.connections[connId].conn.Close()
			break
		}
	}
	if _, ok := h.identityClients[c.Info.Username]; !ok {
		h.identityClients[c.Info.Username] = make(mapPlatformId)
	}
	h.identityClients[c.Info.Username][c.Info.Platform] = c.Id
	return nil
}

func (h *hub) Unregister(c Client, isLocked ...bool) error {
	if len(isLocked) == 0 || !isLocked[0] {
		h.lock.Lock()
	}
	if c.conn != nil {
		_ = c.conn.WriteClose(closeCodePolicyViolation, "policy violation")
		_ = c.conn.Close()
	}
	delete(h.connections, c.Id)
	if identityClient, ok := h.identityClients[c.Info.Username]; ok {
		if id, ok := identityClient[c.Info.Platform]; ok && id == c.Id {
			delete(identityClient, c.Info.Platform)
			if len(identityClient) == 0 {
				delete(h.identityClients, c.Info.Username)
			}
		}
	}
	if len(isLocked) == 0 || !isLocked[0] {
		h.lock.Unlock()
	}
	return nil
}

func (h *hub) SendToPlatform(to string, platform int, data []byte) (string, error) {
	if connection := h.getReceiverConnectionByUsernameAndPlatform(to, platform); connection != nil {
		return h.SendByConn(connection, data)
	}
	return "", ErrNoConnection
}

func (h *hub) SendByConn(conn *websocket.Conn, data []byte) (string, error) {
	return conn.Session().(string), conn.WriteMessage(websocket.BinaryMessage, data)
}

func (h *hub) getReceiverConnectionByUsernameAndPlatform(username string, platform int) *websocket.Conn {
	h.lock.RLock()
	defer h.lock.RUnlock()
	if id, ok := h.identityClients[username][platform]; ok {
		conn := h.connections[id].conn
		return conn
	}
	return nil
}

func (h *hub) DisconnectByUsername(username string) error {
	h.lock.Lock()
	defer h.lock.Unlock()
	for _, id := range h.identityClients[username] {
		_ = h.connections[id].conn.WriteClose(closeCodePolicyViolation, "policy violation")
		_ = h.connections[id].conn.Close()
	}
	return nil
}

func (h *hub) GetAllUsername() []string {
	h.lock.RLock()
	defer h.lock.RUnlock()
	usernames := make([]string, 0, len(h.identityClients))
	for username := range h.identityClients {
		usernames = append(usernames, username)
	}
	return usernames
}

func (h *hub) GetIdentityClients() map[string][]int {
	h.lock.RLock()
	defer h.lock.RUnlock()
	clients := make(map[string][]int)
	for username, client := range h.identityClients {
		for platform := range client {
			clients[username] = append(clients[username], platform)
		}
	}
	return clients
}

func (h *hub) GetClientByConn(conn *websocket.Conn) (Client, error) {
	connId := conn.Session().(string)
	h.lock.RLock()
	defer h.lock.RUnlock()
	if client, ok := h.connections[connId]; ok {
		return client, nil
	}
	return Client{}, ErrUserNotFound
}

func (h *hub) reduceMemoryFootprint() {
	runtime, _ := time.Parse(timeLayoutHHMMSS24h, h.option.ReduceMemoryTime)
	currentTime := time.Now()
	nextTick := time.Date(currentTime.Year(), currentTime.Month(),
		currentTime.Day(), runtime.Hour(), runtime.Minute(), runtime.Second(), 0, time.Local)
	if nextTick.Before(currentTime) {
		nextTick = nextTick.Add(reduceMemoryInterval)
	}
	diff := nextTick.Sub(currentTime)
	time.Sleep(diff)
	h.replaceMapConnections()
	ticker := time.NewTicker(reduceMemoryInterval)
	for range ticker.C {
		h.replaceMapConnections()
	}
}

func (h *hub) replaceMapConnections() {
	start := time.Now()
	h.startDowntimeAt = time.Now().Unix()
	h.lock.Lock()
	defer func() {
		h.lock.Unlock()
		h.downtime = time.Since(start).Milliseconds()
	}()
	connections := make(map[string]Client)
	for key, value := range h.connections {
		connections[key] = value
	}
	h.connections = connections
	identityClients := make(map[string]mapPlatformId)
	for key, value := range h.identityClients {
		identityClient := make(mapPlatformId)
		for platform, id := range value {
			identityClient[platform] = id
		}
		identityClients[key] = identityClient
	}
	h.identityClients = identityClients
}

func (h *hub) GetLastDowntime() int64 {
	return h.downtime
}

func (h *hub) GetLastStartDowntimeAt() int64 {
	return h.startDowntimeAt
}

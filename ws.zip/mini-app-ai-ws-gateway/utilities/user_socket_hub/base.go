package user_socket_hub

import (
	"fmt"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/lesismal/nbio/nbhttp/websocket"
	"mini-app-ai-ws-gateway/utilities/log_file"
)

const (
	reduceMemoryInterval    = time.Hour * 24
	defaultReduceMemoryTime = "01:00:00"
	timeLayoutHHMMSS24h     = "15:04:05"
)

var (
	globalHub Hub
)

type Hub interface {
	InitGlobal()
	Register(info ClientInfo, conn *websocket.Conn) error
	Unregister(c Client, isLocked ...bool) error
	SendToPlatform(to string, platform int, data []byte) (socketId string, err error)
	SendByConn(conn *websocket.Conn, data []byte) (socketId string, err error)
	GetAllUsername() []string
	DisconnectByUsername(username string) error
	GetIdentityClients() map[string][]int
	GetClientByConn(conn *websocket.Conn) (Client, error)
	GetLastDowntime() int64
	GetLastStartDowntimeAt() int64
}

type mapPlatformId map[int]string

type hub struct {
	lock            *sync.RWMutex
	connections     map[string]Client
	identityClients map[string]mapPlatformId
	option          HubOption
	startDowntimeAt int64
	downtime        int64
}

type ClientInfo struct {
	Username string `json:"username"`
	Platform int    `json:"platform"`
}

type Client struct {
	connectedAt time.Time
	conn        *websocket.Conn
	Id          string
	Info        ClientInfo
}

func NewClient(info ClientInfo, conn *websocket.Conn) Client {
	connId := fmt.Sprintf("%s-%s", info.Username, uuid.NewString())
	conn.SetSession(connId)
	return Client{
		conn:        conn,
		Info:        info,
		Id:          connId,
		connectedAt: time.Now(),
	}
}

func (c Client) GetConnectedAt() time.Time {
	return c.connectedAt
}

type HubOption struct {
	Logger           log_file.Service
	ReduceMemoryTime string
}

var hubOptionDefault = HubOption{
	Logger:           NewLogService(),
	ReduceMemoryTime: defaultReduceMemoryTime,
}

func NewHub(opts ...HubOption) (Hub, error) {
	hubOpt := hubOptionDefault
	if len(opts) > 0 {
		opt := opts[0]
		if opt.Logger != nil {
			hubOpt.Logger = opt.Logger
		}
		if opt.ReduceMemoryTime != "" {
			if _, err := time.Parse(timeLayoutHHMMSS24h, opt.ReduceMemoryTime); err != nil {
				return nil, err
			}
			hubOpt.ReduceMemoryTime = opt.ReduceMemoryTime
		}
	}
	h := &hub{
		lock:            new(sync.RWMutex),
		connections:     make(map[string]Client),
		identityClients: make(map[string]mapPlatformId),
		option:          hubOpt,
		downtime:        0,
	}
	go h.reduceMemoryFootprint()
	return h, nil
}

func GetHub() Hub {
	return globalHub
}

package tool

import "net/http"

type Service interface {
	ReadUserIP(r *http.Request) string
	ExtractClientIPAddress(r *http.Request) string
}

type service struct{}

func New() Service {
	return &service{}
}

package bridge_socket_hub

const closeCodePolicyViolation = 1008

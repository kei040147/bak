package bridge_socket_hub

import (
	"sync"
	"sync/atomic"
	"time"

	"github.com/lesismal/nbio/nbhttp/websocket"
	"mini-app-ai-ws-gateway/utilities/log_file"
)

const (
	reduceMemoryInterval    = time.Hour * 24
	defaultReduceMemoryTime = "01:00:00"
	timeLayoutHHMMSS24h     = "15:04:05"
)

var (
	globalHub Hub
)

type Hub interface {
	InitGlobal()
	Register(info ClientInfo, conn *websocket.Conn) error
	Unregister(c Client, isLocked ...bool) error
	SendByConn(conn *websocket.Conn, data []byte) (socketId string, err error)
	GetClientByConn(conn *websocket.Conn) (Client, error)
	GetLastDowntime() int64
	GetLastStartDowntimeAt() int64
	SendToOneBridge(label string, data []byte) (string, error)
}

type hub struct {
	lock              *sync.RWMutex
	bridgeConnections map[string]BridgeConnection
	option            HubOption
	startDowntimeAt   int64
	downtime          int64
}

type BridgeConnection struct {
	connections     map[string]Client
	roundRobinIndex *atomic.Int64
}

type ClientInfo struct {
	Label    string `json:"label"`
	Identity string `json:"identity"`
}

type Client struct {
	connectedAt time.Time
	conn        *websocket.Conn
	Id          string
	Info        ClientInfo
}

func NewClient(info ClientInfo, conn *websocket.Conn) Client {
	connId := generateConnectionId(info.Label)
	conn.SetSession(connId)
	return Client{
		conn:        conn,
		Info:        info,
		Id:          connId,
		connectedAt: time.Now(),
	}
}

func (c Client) GetConnectedAt() time.Time {
	return c.connectedAt
}

type HubOption struct {
	Logger           log_file.Service
	ReduceMemoryTime string
}

var hubOptionDefault = HubOption{
	Logger:           NewLogService(),
	ReduceMemoryTime: defaultReduceMemoryTime,
}

func NewHub(opts ...HubOption) (Hub, error) {
	hubOpt := hubOptionDefault
	if len(opts) > 0 {
		opt := opts[0]
		if opt.Logger != nil {
			hubOpt.Logger = opt.Logger
		}
		if opt.ReduceMemoryTime != "" {
			if _, err := time.Parse(timeLayoutHHMMSS24h, opt.ReduceMemoryTime); err != nil {
				return nil, err
			}
			hubOpt.ReduceMemoryTime = opt.ReduceMemoryTime
		}
	}
	h := &hub{
		lock:              new(sync.RWMutex),
		bridgeConnections: make(map[string]BridgeConnection),
		option:            hubOpt,
		downtime:          0,
	}
	go h.reduceMemoryFootprint()
	return h, nil
}

func GetHub() Hub {
	return globalHub
}

package bridge_socket_hub

import "errors"

var (
	ErrNoConnection     = errors.New("no connection")
	ErrBridgeNotFound   = errors.New("bridge not found")
	ErrBridgeRegistered = errors.New("bridge already registered")
)

package bridge_socket_hub

import (
	"sync/atomic"
	"time"

	"github.com/lesismal/nbio/nbhttp/websocket"
)

func (h *hub) InitGlobal() {
	globalHub = h
}

func (h *hub) Register(info ClientInfo, conn *websocket.Conn) error {
	c := NewClient(info, conn)
	h.lock.Lock()
	defer h.lock.Unlock()
	if _, ok := h.bridgeConnections[info.Label]; !ok {
		h.bridgeConnections[info.Label] = BridgeConnection{
			connections:     make(map[string]Client),
			roundRobinIndex: new(atomic.Int64),
		}
	}
	for _, client := range h.bridgeConnections[info.Label].connections {
		if client.Info.Identity == c.Info.Identity {
			if c.conn != nil {
				_ = c.conn.WriteClose(closeCodePolicyViolation, "policy violation")
				_ = c.conn.Close()
			}
			return ErrBridgeRegistered
		}
	}
	h.bridgeConnections[info.Label].connections[c.Id] = c
	return nil
}

func (h *hub) Unregister(c Client, isLocked ...bool) error {
	if len(isLocked) == 0 || !isLocked[0] {
		h.lock.Lock()
	}
	if c.conn != nil {
		_ = c.conn.WriteClose(closeCodePolicyViolation, "policy violation")
		_ = c.conn.Close()
	}
	delete(h.bridgeConnections[c.Info.Label].connections, c.Id)
	if len(h.bridgeConnections[c.Info.Label].connections) == 0 {
		delete(h.bridgeConnections, c.Info.Label)
	}
	if len(isLocked) == 0 || !isLocked[0] {
		h.lock.Unlock()
	}
	return nil
}

func (h *hub) SendToOneBridge(label string, data []byte) (string, error) {
	connections := h.bridgeConnections[label].connections
	numConnections := int64(len(connections))
	if numConnections == 0 {
		return "", ErrNoConnection
	}
	clientIndex := h.bridgeConnections[label].roundRobinIndex.Load() % numConnections
	h.bridgeConnections[label].roundRobinIndex.Store(clientIndex + 1)
	var index int64 = 0
	for _, connection := range connections {
		if index == clientIndex {
			return h.SendByConn(connection.conn, data)
		}
		index++
	}
	return "", ErrNoConnection
}

func (h *hub) SendByConn(conn *websocket.Conn, data []byte) (string, error) {
	return conn.Session().(string), conn.WriteMessage(websocket.BinaryMessage, data)
}

func (h *hub) GetClientByConn(conn *websocket.Conn) (Client, error) {
	connId := conn.Session().(string)
	h.lock.RLock()
	defer h.lock.RUnlock()
	label := extractLabelFromConnectionId(connId)
	if bridgeConnection, ok := h.bridgeConnections[label]; ok {
		if client, ok := bridgeConnection.connections[connId]; ok {
			return client, nil
		}
	}
	return Client{}, ErrBridgeNotFound
}

func (h *hub) reduceMemoryFootprint() {
	runtime, _ := time.Parse(timeLayoutHHMMSS24h, h.option.ReduceMemoryTime)
	currentTime := time.Now()
	nextTick := time.Date(currentTime.Year(), currentTime.Month(),
		currentTime.Day(), runtime.Hour(), runtime.Minute(), runtime.Second(), 0, time.Local)
	if nextTick.Before(currentTime) {
		nextTick = nextTick.Add(reduceMemoryInterval)
	}
	diff := nextTick.Sub(currentTime)
	time.Sleep(diff)
	h.replaceMapConnections()
	ticker := time.NewTicker(reduceMemoryInterval)
	for range ticker.C {
		h.replaceMapConnections()
	}
}

func (h *hub) replaceMapConnections() {
	start := time.Now()
	h.startDowntimeAt = time.Now().Unix()
	h.lock.Lock()
	defer func() {
		h.lock.Unlock()
		h.downtime = time.Since(start).Milliseconds()
	}()
	connections := make(map[string]Client)
	for label, bridgeConnection := range h.bridgeConnections {
		for key, value := range bridgeConnection.connections {
			connections[key] = value
		}
		h.bridgeConnections[label] = BridgeConnection{
			connections:     connections,
			roundRobinIndex: new(atomic.Int64),
		}
	}
}

func (h *hub) GetLastDowntime() int64 {
	return h.downtime
}

func (h *hub) GetLastStartDowntimeAt() int64 {
	return h.startDowntimeAt
}

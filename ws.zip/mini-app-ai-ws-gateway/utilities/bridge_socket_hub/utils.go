package bridge_socket_hub

import (
	"fmt"

	"github.com/google/uuid"
)

func extractLabelFromConnectionId(connectionId string) (label string) {
	lengthConnectionId := len(connectionId)
	uuidLength := 36
	if lengthConnectionId <= uuidLength {
		return label
	}
	startUuidIndex := len(connectionId) - uuidLength - 1
	return connectionId[:startUuidIndex]
}

func generateConnectionId(label string) string {
	return fmt.Sprintf("%s-%s", label, uuid.NewString())
}

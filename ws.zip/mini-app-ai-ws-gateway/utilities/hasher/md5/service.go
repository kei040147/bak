package md5

import (
	"crypto/md5" //nolint:gosec

	"mini-app-ai-ws-gateway/utilities/hasher"
)

func New() hasher.Service {
	return hasher.New(md5.New()) //nolint:gosec
}

package sha256

import (
	"crypto/sha256"

	"mini-app-ai-ws-gateway/utilities/hasher"
)

func New() hasher.Service {
	return hasher.New(sha256.New())
}

package log_file

import (
	"fmt"
	"os"
	"time"

	"github.com/rs/zerolog"
	"gopkg.in/natefinch/lumberjack.v2"
)

var global Service

const (
	logFilePermission   = 0644
	logFolderPermission = 0744
)

const dateDuration = 24 * time.Hour
const defaultMaxBackupFile = 7

const rfc3339MilliFormat = "2006-01-02T15:04:05.999Z07:00"

type Service interface {
	Init()
	GetLogger() *zerolog.Logger
	GetDomain() string
	GetDomainEventLogger() *zerolog.Event
}

type service struct {
	nextDate         time.Time
	lumberjackLogger *lumberjack.Logger
	logger           *zerolog.Logger
	option           Option
}

type Option struct {
	LogFilePath   string
	ServerDomain  string
	MaxBackupFile int
}

var defaultOption = Option{
	LogFilePath:   "./tmp/service.log",
	MaxBackupFile: defaultMaxBackupFile,
}

func New(opts ...Option) Service {
	opt := defaultOption
	if len(opts) > 0 {
		opt = opts[0]
	}
	filePath := fmt.Sprintf("%s/service.log", opt.LogFilePath)
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		_ = os.Mkdir(opt.LogFilePath, logFolderPermission)
		if err = os.WriteFile(filePath, make([]byte, 0), logFilePermission); err != nil {
			panic(err)
		}
	}

	return &service{
		nextDate: time.Now().Truncate(dateDuration).Add(dateDuration),
		lumberjackLogger: &lumberjack.Logger{
			Filename:   filePath,
			MaxBackups: opt.MaxBackupFile,
		},
		option: opt,
	}
}

func GetGlobal() Service {
	return global
}

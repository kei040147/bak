package log_file

import (
	"time"

	"github.com/rs/zerolog"
)

func (s *service) GetLogger() *zerolog.Logger {
	return s.logger
}

func (s *service) Init() {
	zerolog.TimeFieldFormat = rfc3339MilliFormat
	log := zerolog.New(s).With().Timestamp().Logger()
	s.logger = &log
	global = s
}

func (s *service) GetDomain() string {
	return s.option.ServerDomain
}

func (s *service) GetDomainEventLogger() *zerolog.Event {
	return s.logger.Info().Str("domain", s.option.ServerDomain)
}

func (s *service) Write(p []byte) (n int, err error) {
	now := time.Now()
	if now.After(s.nextDate) {
		if err = s.lumberjackLogger.Rotate(); err != nil {
			return 0, err
		}
		s.nextDate = now.Truncate(dateDuration).Add(dateDuration)
	}
	return s.lumberjackLogger.Write(p)
}

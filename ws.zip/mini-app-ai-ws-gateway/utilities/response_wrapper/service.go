package response_wrapper

import (
	"bytes"
	"net/http"
)

func (s *service) Write(buf []byte) (int, error) {
	s.body.Write(buf)
	return (*s.writer).Write(buf)
}

func (s *service) Header() http.Header {
	return (*s.writer).Header()
}

func (s *service) WriteHeader(statusCode int) {
	s.statusCode = statusCode
	(*s.writer).WriteHeader(statusCode)
}

func (s *service) StatusCode() int {
	return s.statusCode
}

func (s *service) Body() *bytes.Buffer {
	return s.body
}

package response_wrapper

import (
	"bytes"
	"net/http"
)

type Service interface {
	Write(buf []byte) (int, error)
	Header() http.Header
	WriteHeader(statusCode int)
	StatusCode() int
	Body() *bytes.Buffer
}

type service struct {
	writer     *http.ResponseWriter
	body       *bytes.Buffer
	statusCode int
}

func New(w http.ResponseWriter) Service {
	return &service{
		writer:     &w,
		body:       new(bytes.Buffer),
		statusCode: http.StatusOK,
	}
}
